# Estado operativo — PIA-PNFT Modular 1.17.1

Corrección del reporte de celular, 1 de octubre de 2026 (Costa Rica).

Se limitaron anchos mínimos de formularios, fieldsets, etiquetas y controles de las herramientas nuevas. Tablas/mapas anchos mantienen desplazamiento local. Menú fijo a la izquierda en pantallas amplias; ocultable con Menú. En pantalla pequeña se mantiene el panel desplegable.

La consulta de semanas ahora exige expresamente todas las semanas enumeradas en el esquema, una entrada por weekNumber. PIA genera la consulta; se lleva manualmente a la IA y se devuelve el JSON para revisión/selectores de incorporación. El JSON debe respetar las semanas existentes; no crea por sí solo semanas faltantes de la proyección.

No se cambian registros, esquemas v6, catálogo, mapas o funciones de 1.17.0. Regresiones Node y verificaciones de fuente, alcance autorizado e integridad se ejecutan para esta entrega. El informe señala qué se verificó. No se certifica diseño visual en el celular de uso, impresión/descargas nativas ni IndexedDB real.

SHA-256 vigente de las tres salidas HTML: `ecb2c8811809287ec870bea70895fe417d5ac3024b7d902f100fc8cf4a5b7d07`.

Consulte `docs/INFORME_VALIDACION_V1.17.1.md` y las guías de 1.17.0 conservadas.
