# Estado operativo — PIA-PNFT Modular 1.17.0

Entrega de código: 2 de octubre de 2026. Base histórica conservada: 1.16.2.

Implementados: menú CSS y herramientas generales; Proyecto JSON completo revisado; biblioteca PDF/DOCX/PPTX/MP4/HTTPS/YouTube; estadísticas por grupo/nivel/ciclo/módulo; seguimiento curricular con fuentes, evidencias y recuperación; filtros; versiones con comparación; plantillas selectivas; pendientes y comentarios de asesoría.

Acuerdo 2027: la asesoría define previamente el problema. Se conservan I. Empatizar/Definir/Idear, II. Prototipar, III. Probar/Evaluar. Varias fases pueden compartir semana. Los indicadores oficiales se resuelven en catálogos protegidos y no se toman de la IA externa.

- Node: 326/326 pruebas aprobadas.
- DOM: herramientas nuevas, Proyecto multifase, edición de evaluación, registros/borradores, comentarios/respuestas, versiones, plantillas, biblioteca vinculada, aislamiento, JSON y portable.
- Regresiones DOM: gestión, mapas históricos/orden automático/semanas, autoguardado, intercambio semanal, contenido Word/PDF y reimportación Word aprobadas.
- Catálogos oficiales, referencias, BASELINE y manifiesto: comparación byte por byte sin cambios (16 archivos).
- Sin backend, API de IA, sincronización automática ni expedientes de alumnos.
- Pendiente: aceptación visual en navegador, navegación móvil real, impresión/descargas nativas y comportamiento de IndexedDB en dispositivos de uso. Las pruebas DOM/adaptador no certifican esas comprobaciones.

Las estadísticas describen minutos de ejecución declarada. Sin información no es cero; dos módulos exigen distribuir tiempo. Relación curricular validada no certifica aprendizaje ni logro del perfil. Las sugerencias son textos orientadores locales para revisión docente.

Los archivos de biblioteca viajan en el ZIP de recursos; JSON/portable conservan solo catálogo y enlaces. Al importar el ZIP se recuperan adjuntos faltantes de fichas compatibles.

SHA-256 vigente de las tres salidas HTML: `12be6c7faa6ef7dc5e253c2a88b0f2c6d19346cefb9ad99b4babec5411b94784`.

Guías: `docs/GUIA_ACTUALIZACION_1.17.0.md`, `docs/ACUERDOS_Y_ENTREGA_1.17.0.md`. Informe: `docs/INFORME_VALIDACION_V1.17.0.md`.
