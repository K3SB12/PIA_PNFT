# Registro de cambios

## 1.17.2

- Extiende la adaptación móvil a la plantilla original y las cuadrículas semanales; 1.17.1 había acotado las herramientas nuevas.
- Apila datos generales y áreas/RdA/saberes/indicadores/mediación/evaluación en pantallas pequeñas; conserva controles, DOM y formato impreso.
- Ajusta campos a 16 px para prevenir zoom de foco de Safari, sin desactivar el zoom del usuario.
- CSS sin dependencia de `:has` para la tabla; controla tamaño mínimo de cuadrículas, cabecera y contenido.
- Verificación de código y regresiones; intento de WebKit bloqueado por dependencias del entorno. No se anuncia prueba aprobada en Safari/iOS.

## 1.17.1

- Corrige posibles desbordamientos en formularios nuevos en celular: fieldset/etiquetas/controles con ancho acotado y tablas/mapas con desplazamiento local.
- Mantiene los controles del selector de planes en pantalla pequeña y evita conservar el margen de menú de escritorio.
- La consulta para semanas exige expresamente una entrada por cada semana del esquema semestral. Conserva importación revisada y selección parcial.
- Verificación de fuente/ensamblado, currículo protegido y regresiones Node; no se certifica diseño visual real en celular.

## 1.17.0

- Menú con estilos, colapso de escritorio, panel móvil y controles de teclado; herramientas generales independientes del activo.
- Proyecto JSON completo revisado, cinco fases en tres etapas, varias fases por semana, tema/problema/condiciones/tiempo y respaldo; acuerdos 2027 en la consulta.
- Biblioteca de archivos y vínculos clasificados, referencias semanales, ZIP con adjuntos y recuperación después de cargar catálogo/portable.
- Estadísticas de ejecución por grupo/nivel/ciclo/módulo y fecha, distribución de minutos entre módulos y ausencia de datos explícita.
- Seguimiento con fuentes oficiales, evidencias, valoración docente, comparación de decisiones y sugerencias de recuperación.
- Filtros de planes, versiones con comparación, plantillas selectivas y pendientes/comentarios con respuesta.
- Borradores independientes de registros confirmados, persistencia en esquema v6 y portable; informes internos separados.
- Preserva archivos protegidos y funciones anteriores. Limitaciones de validación nativa detalladas en el informe 1.17.0.

## 1.16.2

- Añade limpiar, eliminar de la lista y recuperar el activo, con confirmación y hasta cinco respaldos completos.
- Añade duplicación independiente y descarga JSON del activo sin otros planes ni respaldos de gestión.
- Impide operaciones destructivas sin respaldo guardado y revierte el estado visible si falla el guardado final.
- Corrige residuos de respuesta IA, comparación y mapa al cambiar o crear un plan.
- Sincroniza campos ocultos del Proyecto y conserva los textos pendientes de confirmación del perfil.
- Conserva currículo, esquema v6, archivos históricos y exportadores oficiales; documenta funciones futuras y límites de validación.

## 1.16.1

- Ordena los mapas nuevos por fase o grupo y semana declarada, con altura calculada según el contenido.
- Muestra semanas en cada saber, agrupaciones y ramas; conserva rangos discontinuos sin ampliarlos.
- Añade ordenación automática reversible y carga revisada de JSON de rutas o propuestas elegidas.
- Conserva la base visual histórica cuando existen posiciones manuales; ordenar explícitamente activa la distribución nueva.
- Corrige pérdida de rangos al migrar fases con `id` o `phaseId`, y conserva notas e historial.
- Mantiene confirmación y huella semántica al mover u ordenar bloques; PNG incluye las semanas.

## 1.16.0

- Incorpora seis vistas, menú lateral, selector y flechas entre planes locales independientes.
- Añade JSON conjunto, intercambio semanal trazable e importación Word/JSON con selección, confirmación y respaldo.
- Refuerza aislamiento de historiales y exportación portable sin duplicación de interfaz.
- Añade acentos PNFT sin recolorear imágenes oficiales.
- Conserva contrato v6, fuente modular y exportadores existentes; documenta la revisión visual bloqueada.


## 1.15.1

- Corrige los accesos **Continuar un planeamiento** y **Abrir** mediante un selector JSON persistente.
- Elimina el temporizador que rompía el gesto autorizado de apertura de archivos en Safari/iOS y otros navegadores.
- La portada permanece visible cuando se cancela la selección y se oculta únicamente después de una carga válida.
- Añade pruebas funcionales para apertura inmediata, cancelación y carga de un planeamiento con esquema v6.

## 1.15.0

- Reorganiza el flujo de III Ciclo y evita desplazamientos de ida y vuelta entre evaluación, Proyecto y constructor de rutas.
- Activa el componente Proyecto únicamente después de la confirmación expresa de un perfil compatible; la decisión sigue bajo responsabilidad docente.
- Presenta el detalle del Proyecto y sus fases oficiales en paneles plegables para reducir carga visual sin ocultar información.
- Corrige el recorrido guiado del constructor con siete destinos únicos y reduce la consulta a IA a tres acciones principales.
- Amplía el contrato de propuestas con producto, justificación, recursos, evidencia, trazabilidad de revisiones e historial de alternativas.
- Solicita confirmación antes de sustituir una propuesta aplicada y conserva la alternativa anterior para comparación.
- Añade orientación local sobre PIA y PNFT sin API, con fuentes, páginas, confianza y salida prudente cuando no existe sustento suficiente.
- Permite preparar y copiar una consulta externa sin transmitir automáticamente datos a ChatGPT o Copilot.
- Incorpora organización y actividades puntuales por semana, persistentes y claramente separadas de las metodologías.
- Oculta controles de fases del Proyecto en semanas solo curriculares sin borrar la información almacenada.
- Refuerza DUA, apoyos diferenciados, privacidad y referencias opcionales para Plan Nacional en prompts y controles.
- Mejora el uso del mapa, calendario, propuestas y orientación local en computadora, tableta y celular.

## 1.14.4

- Renueva la portada con los recursos oficiales MEP, PIA y PNFT incrustados localmente y conservados sin filtros ni redibujos.
- Presenta Explorar, Comenzar y Continuar como tres botones completos e independientes, sin flechas ni repetición de “Elegir”.
- Extiende la línea morada bajo el nombre completo del Programa Nacional de Formación Tecnológica.
- Consolida el tema claro/oscuro mediante variables semánticas, foco AA y refuerzo de bordes y sombras en los nodos del mapa.
- Corrige las superficies claras residuales documentadas por docentes y verifica automáticamente contraste 4.5:1 en la paleta oscura esencial.
- Sustituye la tarjeta PNFT de la portada por el conjunto transparente de hexágonos, sin “Año 2026” ni pie duplicado, y reduce el espacio antes de los tres botones sin alterar su diseño.
- Completa el tema oscuro de Contextualización/DUA e Indicadores de referencia: contenedores, encabezados, ayudas, campos, tarjetas y avisos utilizan superficies y textos coherentes.
- Revisión correctiva: ordena currículo, mediación, evidencia, alternativas de indicadores, decisión docente, comprobación de alineamiento e instrumento en todos los prompts pedagógicos.
- Aclara que los dos indicadores de evaluación son alternativas editables y no dos obligaciones simultáneas.
- Vincula los prompts semestral y de estrategias de III Ciclo con una huella semántica de la ruta; informa estados sincronizado, desactualizado o no comprobable sin sobrescribir ediciones docentes.
- Excluye posiciones, zoom, vista y tema de la huella para que los ajustes visuales del mapa no invaliden el contenido pedagógico.
- Añade reflexión docente propia a cada semana, persistente y exportable dentro de la semana seleccionada, conservando la estructura y los mensajes originales de PIA; elimina la repetición general final sin perder datos históricos.
- Completa la cobertura de contraste del tema oscuro en semanas, currículo, campos editables, ayudas, tablas, modales, trayectoria curricular, RdA, estados desactivados e indicadores.
- Restaura íntegramente **PIA Journey · La Ruta del Docente**, incluido el mapa de progresión curricular o “ruta del tesoro”, y elimina distintivos técnicos impropios de la portada.
- Cierre de segunda iteración: exige alternativas de IA estructuralmente distintas y advierte duplicados exactos de distribución.
- Añade matriz completa de comparación por propuesta antes de aplicarla.
- Amplía la tabla editable por saber con agrupación, evidencia, Trabajo cotidiano/Tarea y contexto o puente.
- Separa en tableta/celular “Desplazar mapa” de “Mover bloques” y conserva las posiciones visuales al guardar y volver a abrir.
- Refuerza el contrato para no inflar Proyecto mediante `integrated` sin contribución auténtica y para explicitar producto, recursos, puentes y evidencias.
- Refuerza contraste del tema oscuro en matrices, porcentajes, controles y panel de continuidad.
- Revisión de cierre sobre una respuesta real de IA: recupera una vista conceptual preliminar por nodos dentro de cada propuesta antes de construir el mapa completo.
- Aclara la distribución como Solo lecciones / Solo Proyecto / Lecciones + Proyecto / Pendiente y añade presencia total en Proyecto y lecciones.
- Permite descargar la respuesta de IA como Markdown y las propuestas validadas como JSON directamente desde PIA, sin depender de adjuntos externos.
- Corrige la navegación por doble clic mapa→tabla evitando reconstruir el nodo en el primer clic.
- Permite reorganizar visualmente los bloques del grafo por arrastre; las coordenadas se guardan como metadatos visuales y nunca cambian currículo, semanas, relaciones ni fases.
- Añade al contrato comparativo oportunidades orientadoras de Trabajo cotidiano o Tarea y prohíbe usar rangos continuos para ocultar momentos temporalmente discontinuos.
- Cierra el circuito PIA → IA → PIA mediante Markdown o JSON validado, sin reemplazo automático de la ruta.
- Añade exportación de consulta Markdown, ruta JSON y mapa PNG, y una acción para solicitar ajustes de la propuesta elegida.
- Añade el panel “Continuar con el planeamiento” con proyección semestral y estrategias semana a semana sobre la misma ruta.
- Persiste respuesta, propuesta, selección, fases y prompt semanal en el archivo de planeamiento.
- Protege las cinco fases de Pensamiento de Diseño, la literalidad curricular, la huella de selección y los límites temporales.
- Corrige la selección inicial de niveles por ciclo y añade tema claro/oscuro persistente.
- Amplía el modal, elimina la superposición de la barra inferior, evita cierre accidental y añade navegación de doble clic mapa→tabla con retorno al mapa.
- Aclara que los porcentajes mostrados describen organización curricular y no participación, logro ni calificación.
- Mantiene la revisión final con DUA, accesibilidad, diagnóstico declarado, evidencias, trabajo cotidiano, tareas e instrumentos sugeridos.
- Incorpora el contrato `pia-route-options-v4`: distingue comparación y revisión, identifica la propuesta elegida, conserva una copia de referencia y valida que sus ajustes mantengan trazabilidad.
- Permite importar respuestas `.json`, `.md` o `.txt` y descargar por separado la propuesta elegida en `.json`.
- Amplía Word y PDF con alcance seleccionable: semestre completo, rango continuo o semanas específicas, sin renumerar ni omitir los campos semanales requeridos.


## 1.9.2

- Sustituye las tarjetas semanales por un calendario visual horizontal dentro del constructor de la ruta curricular.
- Distingue diagnóstico, mediación curricular, Proyecto y fases APD, trabajo cotidiano y tareas o calendario.
- Elimina la inferencia que ubicaba automáticamente el Proyecto al final del periodo a partir de su duración.
- Mantiene visibles los rangos pendientes, las excepciones sin fecha y las rutas en borrador sin inventar semanas.
- Excluye ventanas evaluativas sugeridas, descartadas, obsoletas o asociadas a un perfil sin confirmar.
- Añade alertas estructurales, tabla accesible y desplazamiento horizontal adaptado a celular y tableta.
- Añade una revisión guiada de relaciones con explicaciones en lenguaje común, justificación docente y revisión de indicadores, evidencia y secuencia temporal; las opciones se rotulan como ayudas de PIA, no categorías oficiales.
- Presenta candidatos por color según términos exactos, área y verbo inicial de los indicadores; elegir un candidato no crea ni valida una conexión.
- Conserva una sola ruta, `schemaVersion: 6`, funcionamiento local y exportaciones oficiales sin cambios.

## 1.9.1

- Sustituye la representación por franjas del organizador de III Ciclo por un grafo conceptual con nodos HTML y conexiones SVG.
- Abre “Ver ejemplo” como un mapa completo de solo lectura sin modificar el plan.
- Añade control visible de trazabilidad para currículo, tiempo, diagnóstico, contexto, DUA, recursos, Proyecto, evaluación y decisiones docentes.
- Amplía el prompt de análisis del mapa con toda la entrada validada y separa datos oficiales, declarados, opcionales y pendientes.
- Conserva tabla accesible, inspector, relaciones editables, línea temporal, exportación PNG, impresión y esquema v6.

## 1.9.0

- Convierte el clasificador de secundaria en un mapa curricular integral, editable y persistente.
- Presenta Proyecto y mediación curricular como una sola ruta con fases APD, saberes, semanas, relaciones y horizonte de RdA.
- Añade inspector, grupos, conexiones, notas, colores, deshacer/rehacer, zoom, vistas, PNG e impresión/PDF del mapa.
- Incorpora capas de saberes procedimentales, actitudinales, ejes transversales, evaluación y referentes curriculares.
- Amplía la auditoría con fases sin vínculo, semanas incompatibles, relaciones incompletas y posibles evidencias duplicadas.
- Genera un prompt para comparar dos o tres rutas técnicamente válidas sin enviar información ni alterar decisiones.
- Conserva `schemaVersion: 6`, operación local, currículo protegido, JSON, autoguardado, portable y exportaciones oficiales.

## 1.8.0

- Sustituye el bloque “Articular currículo y Proyecto como un solo proceso” por un organizador independiente y comprensible de la ruta curricular del semestre.
- Añade cuatro decisiones de organización, un mapa conceptual responsivo, tabla accesible, modos guiado/directo y auditoría orientativa.
- Permite asignar a cada saber una función distinta respecto del Proyecto sin fragmentar el módulo ni modificar indicadores oficiales.
- Conserva la doble metodología como excepción explícita y mantiene la auditoría de fases, puentes, tiempo y duplicación.
- Incorpora la ruta confirmada al prompt semestral, con pendientes visibles y prohibición de duplicar evidencias o sumar dos veces semanas integradas.
- Añade pruebas para mapas de 7.º–9.º, áreas ausentes, persistencia v6, accesibilidad e integridad de la distribución.

## 1.7.5

- Oculta por defecto la selección manual de técnica, instrumento y criterio docente para evitar duplicarla con la recomendación de IA.
- Añade un control explícito para docentes que ya conocen la técnica y el instrumento que utilizarán.
- Solicita a la IA una sola recomendación contextualizada conforme a MEP y PNFT cuando el control manual está desactivado.
- Sustituye la restricción “conjunto acotado… no evalúe todo el semestre” por el alcance oficial relacionado con saberes conceptuales, procedimentales y actitudinales del módulo.
- Exige experiencias integradas y viables en un máximo de dos lecciones, sin fragmentar el diagnóstico por saber ni convertir indicadores actuales en prerrequisitos.
- Conserva selecciones manuales de planes históricos mediante migración compatible con esquema v6.

## 1.7.4

- Corrige la procedencia de la técnica y el instrumento diagnóstico cuando se solicita recomendación a la IA.
- Añade un estado visible que distingue recomendaciones pendientes de selecciones docentes expresas.
- Impide que el prompt rotule una recomendación de IA como decisión de la persona docente.
- Conserva esa distinción en el prompt semestral y en el modelo diagnóstico de Word.
- Aclara que revisar o anexar una respuesta de IA no confirma automáticamente sus recomendaciones.

## 1.7.3

- Reformula la coordinación metodológica de secundaria para presentar currículo y Proyecto como una sola ruta articulada mediante APD.
- Identifica la metodología completa adicional como una excepción y muestra sus semanas solo cuando corresponde.
- Refuerza la explicación diagnóstica de “Condiciones de entrada para los saberes actuales”.
- Corrige la adaptación vertical de los diálogos de prompt y habilita desplazamiento interno en pantallas de menor altura.
- Sustituye “lecciones administrativas” por “lecciones pedagógicas” en la interfaz y documentación operativa.

## 1.7.2

- Amplía el diagnóstico con técnica, instrumento y generación de una plantilla imprimible sin resultados inventados.
- Añade coordinación metodológica responsable en secundaria y alertas ante el uso concurrente de APD con ABR, ABJ u otra metodología.
- Incorpora un escenario preventivo no oficial de minutos efectivos, manteniendo el bloque oficial de 80 minutos.
- Corrige la omisión de Operadores relacionales en 3.º, Módulo 1, según la guía docente oficial de Primaria.
- Actualiza documentación y regresión a 236 saberes–indicadores y 165 pruebas.

## 1.7.1 — revisión de asesoría

- Incorpora competencias específicas, perfiles de salida y propósito oficial del módulo como marco visible y trazable para cada selección.
- Solicita integración de dos o más saberes cuando exista lógica pedagógica, sin impedir tratamientos individuales justificados por profundidad.
- Aplica DUA al diseño general y conserva como opcional el registro de contexto y apoyos específicos.
- Añade inventario estructurado de recursos generales sin datos personales.
- Permite descargar un modelo diagnóstico editable en Word, rotulado como ejemplo no obligatorio y sin hallazgos inventados.
- Añade auditoría de contribución de la ruta y comprobación técnica de su estructura, sin certificar logro o RdA alcanzado.
- Aclara que Proyecto no impone tema único ni cantidad universal de indicadores.
- Conserva el esquema JSON v6, currículo protegido, funcionamiento local y compatibilidad histórica.

## 1.7.1

- Corrige el congelamiento de “Explorar un ejemplo de planeamiento” causado por aplicar `inert` al contenedor ancestro de la propia experiencia.
- Aísla únicamente los elementos hermanos del plan y restaura sus estados de accesibilidad al cerrar.
- Añade una guía opcional para DUA, acceso, apoyos no significativos y adecuación significativa o PEI previamente aprobada.
- Incorpora apoyos estructurados de mediación y coordinación institucional sin datos personales.
- Amplía el perfil III Ciclo y Ciclo Diversificado Vocacional — Plan Nacional con coordinación, diagnóstico, selección/dosificación de saberes y tiempo semanal.
- Explicita que PIA llega curricularmente hasta 9.º y no genera contenido oficial inexistente para 10.º–12.º.
- Conserva `schemaVersion: 6`, currículo protegido, Ruta hacia el RdA, operación local y compatibilidad histórica.

## 1.7.0

- Incorpora “Explorar ruta hacia el RdA” como consulta curricular modular de solo lectura.
- Construye una ruta estructural desde Preescolar hasta 9.º usando familias, niveles, módulos, áreas, saberes, indicadores literales y RdA por ciclo.
- Separa el vínculo estructural de las correspondencias pedagógicas aprobadas en un catálogo independiente.
- Mantiene toda relación no aprobada como pendiente de validación curricular y prohíbe completarla mediante IA.
- Distingue desarrollo explícito, presencia o fortalecimiento con respaldo, ausencia de registro, no aplicable y área ausente.
- Mantiene el nivel actual como único currículo planificable; antecedentes y continuidades no pasan a semanas, prompts ni exportaciones.
- Conserva `schemaVersion: 6`, currículo protegido, operación local y compatibilidad con 1.6.15.

## 1.6.15

- Exige confirmación docente explícita del perfil de evaluación antes de generar referencias evaluativas o el prompt semestral.
- Condiciona Proyecto a un perfil confirmado y conserva sus datos cuando el perfil está pendiente.
- Añade confirmación especial para proyectar ambos módulos dentro de un mismo marco temporal.
- Calcula presupuesto neto en lecciones y minutos, descontando diagnóstico, excepciones cuantificadas y reserva de evaluación/realimentación.
- Solicita a la IA un balance numérico entre minutos netos, asignados y diferencia.
- Renombra y delimita la revisión de IA como comprobación técnica, con trazabilidad de saberes, RdA, indicadores y balance temporal.
- Corrige la comprobación de saberes procedimentales y actitudinales de Preescolar.
- Añade prueba exhaustiva de 235 indicadores y 20 combinaciones nivel–módulo.
- Mantiene currículo, esquema JSON v6, funcionamiento local, Proyecto y exportaciones.

## 1.6.14

- La portada sustituye “Aprender metodologías del PNFT” por **“Explorar un ejemplo de planeamiento”**.
- Incorpora una experiencia formativa local, independiente y progresiva con siete momentos: horizonte, punto de partida, ruta curricular, metodología, proyección, semana y revisión.
- Añade laboratorios de decisiones para ABJ, ABR y APD, fundamentados en los documentos metodológicos aportados.
- Integra ejemplos diferenciados para Preescolar, I, II y III Ciclo, además de una profundización sobre currículo y Proyecto en secundaria.
- Consulta en modo de solo lectura los catálogos existentes de currículo, RdA, trayectoria, Preescolar y Proyecto; el recorrido no crea ni modifica referentes oficiales.
- Distingue de forma permanente referente oficial, ejemplo formativo y decisión docente.
- Explica la relación entre semanas proyectadas y lecciones planificadas, el propósito de los prompts y la diferencia entre autoguardado, JSON y exportaciones.
- El progreso formativo se guarda únicamente en `pia.learning.example.v1`; queda fuera del JSON del plan, autoguardado del plan, PDF y Word.
- Los controles del recorrido quedan aislados de los eventos de edición del planeamiento y la descarga portable elimina cualquier contenido transitorio del recorrido.
- Se agregan navegación flexible, foco visible, salida con `Esc`, reducción de movimiento, diseño adaptable y lenguaje que evita presentar el recorrido como certificación o receta.

## 1.6.13

- Corrección curricular: las celdas vacías se registran como `no-curricular-record`; no se interpretan
  como fortalecimiento, enseñanza, dominio ni evaluación. `N/A` continúa como no aplicable.
- Estados preparados para presencia conceptual y fortalecimiento sin evaluación únicamente cuando una
  fuente curricular los respalde expresamente.
- Trayectoria con tarjetas y tabla comparativa, filtros por módulo, área y alcance, encabezado contextual,
  RdA y fuente visible por guía, nivel, módulo y área.
- Íconos PNFT aportados incorporados localmente al HTML autónomo; texto y color se mantienen como señales
  complementarias de accesibilidad.
- Trayectoria, familias y alcances anteriores/posteriores retirados del prompt semestral.
- Diagnóstico inicialmente desactivado y con cero lecciones; incorporación al prompt mediante selección
  expresa y acción independiente para reiniciarlo sin alterar módulos, saberes, semanas o proyección.
- “Nota” sustituida por “Observación o decisión docente”; aclaración de que “Durante todo el periodo” no
  impone evaluación semanal ni una cantidad fija de observaciones.
- Auditoría temporal posterior y localización “Etapa de desarrollo → Prototipar” preservadas.
- JSON v6, currículo oficial, exportaciones y funcionamiento portable preservados.
- 132 pruebas automatizadas aprobadas.

## 1.6.12

- Vista local **Trayectoria curricular del PNFT** con filtros por área, tarjetas de familia y lectura
  ANTES–AHORA–DESPUÉS basada en las 38 familias de la matriz oficial.
- Indicadores literales del PNFT en los niveles explícitos y diferenciación visible entre fortalecimiento
  sin evaluación directa y ausencia del saber o área en la trayectoria.
- AHORA limitado a los saberes efectivamente seleccionados; la vista no modifica estado ni exportaciones.
- Auditoría temporal posterior incorporada al prompt semestral con tres conclusiones controladas y
  prohibición de juzgar la viabilidad mediante un conteo aislado de indicadores y bloques.
- Presentación localizada **Etapa de desarrollo → Prototipar** en el prompt de Proyecto.
- JSON v6, currículo, semanas, diagnóstico, Proyecto, PDF, Word y portable preservados.
- 127 pruebas automatizadas aprobadas; revisión humana final en Edge/Chrome pendiente.

## 1.6.11

- Acción **Preparar evaluación diagnóstica** reubicada después de Saberes para la proyección.
- Selector de 0–2 lecciones conservado en Marco temporal y diagnóstico mantenido como función opcional.
- Habilitación del acceso diagnóstico únicamente con ciclo, nivel, módulo, área, saber conceptual y
  una o dos lecciones seleccionadas; la proyección semestral no queda condicionada por esta habilitación.
- Glosario contextual centralizado para conceptos curriculares, pedagógicos, normativos y funciones de PIA.
- Ayudas accesibles mediante puntero, foco, clic o toque; cierre por clic externo, cambio de ayuda o `Esc`.
- Posicionamiento responsivo, una sola ayuda visible y exclusión expresa de impresión y exportaciones.
- JSON v6, currículo del PNFT, prompts, Proyecto, semanas, autoguardado, PDF, Word y portable preservados.
- Validación automatizada final: 120/120 pruebas aprobadas.

## 1.6.10

- Flujo diagnóstico persistente con modos asesor/docente, máximo dos lecciones, áreas de valoración
  integradas y registro de decisiones generales sin datos personales.
- Separación explícita entre antecedentes por explorar, currículo actual obligatorio y alcances posteriores.
- Ventanas evaluativas sugeridas para trabajo cotidiano, tareas, prueba de ejecución y Proyecto, con
  estados sugerida/confirmada/descartada, semana editable y nota docente.
- Reglas 2026 para tareas y prueba de ejecución incorporadas como orientación; ninguna sugerencia
  escribe el planeamiento ni sustituye el calendario institucional.
- Momentos confirmados incorporados al prompt semestral y al afinamiento de la semana aplicable.
- Revisión local de respuestas de IA con comprobaciones de literalidad, estructura, selección curricular,
  alcance temporal y afirmaciones indebidas de logro; almacenamiento separado del planeamiento oficial.
- Persistencia de diagnóstico, sugerencias, respuestas y reportes mediante JSON v6, autoguardado y portable.
- Currículo del PNFT, Preescolar, Proyecto, juego metodológico, Word, PDF y línea separada 1.7.x preservados.

## 1.6.9

- Juego metodológico local desde la portada con siete misiones y realimentación inmediata.
- Ruta propia para Preescolar: Básico/Óptimo, juego, exploración, criterios formativos, RdA y perfil.
- Escenarios de secundaria con una ruta APD integrada o metodología curricular coordinada con APD del Proyecto.
- Activación explícita de Contextualización y DUA; sus datos se omiten del prompt cuando no se activa.
- Prompt diagnóstico guiado por proceso y tres dimensiones, dentro del máximo de dos lecciones.
- Ficha condicional de fundamentación para Otra metodología.
- Prompt semanal sustituido funcionalmente por Afinar semana con IA.
- Prototipar y Probar/Evaluar vinculados con indicadores oficiales del módulo; compatibilidad histórica preservada.
- Currículo del PNFT, JSON v6, autoguardado, PDF, Word y portable conservados.

## 1.6.8

- Afinamiento del 7 de setiembre: diagnóstico nuevamente limitado a 0–2 lecciones, conforme a la
  decisión pedagógica vigente y sin borrar contenido semanal.
- Prompt semestral condicional: metodología requerida; fechas, ejes, contexto, condiciones y referencias
  se omiten cuando no fueron aportados; los valores neutrales no generan texto “pendiente”.
- Ruta curricular explícita por área, saber, indicador de logro del PNFT y RdA, con numeración continua
  de las tareas realmente aplicables y Proyecto solo en el perfil correspondiente.
- Etiquetas de Contextualización y DUA afinadas en lenguaje docente, grupal y no estigmatizante.
- Portada local MEP–PNFT–PIA con inicio, carga de JSON, preferencia de omisión por dispositivo y
  retorno seguro al inicio; excluida de PDF y Word.
- Identidad institucional opcional limitada a escudo y lema, alineada a la izquierda y sin duplicar
  el nombre del centro educativo.
- Contextualización y DUA enriquecida con perfil de implementación, condiciones complementarias,
  escenario tecnológico y punto de partida grupal, sin recopilar datos personales.
- Perfiles contextuales para Regular, Aula Edad, aulas integradas, Vocacional y EPJA, separados de los
  perfiles de evaluación y sujetos a validación institucional cuando no exista una regla confirmada.
- Indicadores de referencia de otros niveles seleccionables únicamente desde el currículo autorizado
  del PNFT; literalidad, procedencia, motivo y contextualización docente conservados por separado.
- Incorporación semanal explícita y reversible de referencias, con persistencia en JSON/autoguardado y
  presencia en las columnas oficiales de PDF/Word cuando están seleccionadas.
- Prompts General, Semestral y Semanal con borradores independientes, guardado explícito, estado visible,
  actualización desde PIA y restablecimiento con confirmación antes de sobrescribir.
- Contrato contextual para DUA, alternativas equivalentes sin conexión, diferenciación de fuentes y
  decisiones que requieren validación institucional.
- Barra de formato contextual 1.6.7, currículo, Preescolar, Proyecto, progresión interna, versión portable
  y compatibilidad con planes anteriores preservados.
- Validación automatizada final: 105/105 pruebas; revisión humana multinavegador y Word recomendada antes
  del despliegue institucional.

## 1.6.7

- Apertura contextual de la barra al seleccionar texto en Mediación o Evaluación.
- Conservación del rango seleccionado para aplicar varios formatos sin regresar al encabezado.
- Identificación visible del campo destinatario y cierre mediante botón, clic externo o tecla `Esc`.
- Acciones prioritarias compactas y opciones secundarias plegadas para no saturar los campos.
- Sangría, limpieza de selección, subtítulos Inicio–Desarrollo–Cierre, pegado limpio opcional y
  vínculos HTTPS con validación docente.
- Indicadores de logro del currículo de FT protegidos y excluidos de los comandos de formato.
- Compatibilidad preservada con JSON v6, autoguardado, Word, PDF y versión portable.
- 96 pruebas automatizadas aprobadas.

## 1.6.6

- Trayectoria curricular detallada conservada al 100% como servicio interno de solo lectura.
- Sustitución del bloque visible AHORA–ANTES–DESPUÉS por una única orientación breve para la IA.
- Familias de los saberes seleccionados incorporadas dinámicamente en esa orientación.
- Salvaguardas de nivel actual, diagnóstico de antecedentes, refuerzos sin evaluación y alcances posteriores.
- Contrato lúdico, curricular y formativo de Preescolar 1.6.5 preservado sin cambios.
- Currículo oficial, JSON v6, semanas, Proyecto y exportaciones sin alteraciones.
- 93 pruebas automatizadas aprobadas.

## 1.6.5

- Competencias específicas y perfil de salida oficiales de Preescolar incorporados al contexto del prompt.
- Contrato de Preescolar con evaluación diagnóstica/formativa y experiencias lúdicas completas por semana.
- Bloque de 80 minutos compatible con ejecución continua o dos lecciones articuladas de 40 minutos.
- Integración por pertinencia pedagógica, sin imponer cantidades mínimas semanales.
- Proyecto omitido en Preescolar, I y II Ciclo y condicionado correctamente en III Ciclo.
- 92 pruebas automatizadas aprobadas.

## 1.6.4

- Trayectoria semestral presentada como AHORA, ANTES y DESPUÉS.
- Eliminación del ruido técnico: estados `N/A`, separadores `/` y mensajes sin niveles intermedios.
- Referencias no continuas diferenciadas de prerrequisitos directos.
- Alcance actual limitado a los saberes seleccionados, sin expansión automática por familia.
- Reglas explícitas para diagnóstico, continuidad posterior y protección del nivel vigente.
- 88 pruebas automatizadas aprobadas.

## 1.6.3

- Etiquetas de antecedentes reformuladas para evitar inferir aprendizaje previo.
- Mandato explícito de planear íntegramente el nivel seleccionado.
- Prerrequisitos sujetos a diagnóstico y apoyos contextualizados.
- Niveles intermedios previos ordenados cronológicamente.
- Cierre de 9.º descrito como límite del catálogo, no como final de la trayectoria educativa.
- 86 pruebas automatizadas aprobadas.

## 1.6.2

> Historial: la semántica de vacíos y el envío de la trayectoria al prompt quedaron corregidos y
> reemplazados en 1.6.13.

- Catálogo relacional interno con 38 familias de progresión, 10 niveles y las cuatro áreas del PNFT.
- Correspondencia exacta de los 235 registros curriculares actuales sin modificar textos oficiales.
- Contexto de fundamento previo, alcance actual y proyección posterior añadido entonces al prompt
  semestral; retirado del prompt en 1.6.13 y trasladado a consulta local.
- Regla aplicada entonces: celda vacía como refuerzo conceptual; corregida en 1.6.13 porque el vacío
  solo acredita ausencia de registro curricular.
- Salvaguardas contra indicadores inventados, evaluaciones inexistentes y afirmaciones de dominio o RdA alcanzado.
- Importador técnico reproducible desde los dos archivos Excel de referencia; sin carga en la interfaz.
- JSON v6, PDF, Word, portable y funcionamiento de 1.6.1 preservados.
- 85 pruebas automatizadas aprobadas.

## 1.6.1

- Filtro curricular independiente por semana para Módulo 1, Módulo 2 o ambos.
- Valor inicial coherente con el semestre para semanas nuevas; compatibilidad conservadora para planes anteriores.
- Áreas, RdA, saberes e indicadores semanales limitados al alcance curricular seleccionado.
- Referencias `saberRefs` con módulo, área y nombre para resolver indicadores sin ambigüedad.
- Avisos de selecciones conservadas fuera del filtro y prohibición de borrado silencioso.
- Panel semanal plegable para áreas, RdA y saberes conceptuales.
- Regeneración semestral sensible a fechas con protección del prompt anterior.
- Mejoras visuales recibidas y verificadas: Contextualización/DUA y soporte desplegables, encabezado de
  Proyección simplificado, orden curricular ajustado y conteos internos de RdA retirados de la interfaz.
- 80 pruebas automatizadas aprobadas.

## 1.6.0

- Selección semestral explícita de Prototipar y Probar/Evaluar.
- Un indicador de logro y dos indicadores de evaluación docentes por cada fase posterior, sin atribución oficial.
- Inicialización segura de los campos semanales desde la proyección y preservación de ediciones por semana.
- Prompt semestral estructurado por etapa y fase, distinguiendo texto oficial de texto docente.
- Persistencia JSON v6 de prompts general, semestral y semanales editados.
- Proyección plegable sin borrado de estado.
- Áreas Word ampliadas y blancas para Reflexiones y Observaciones.
- 75 pruebas automatizadas aprobadas.

## 1.5.2

- Indicadores de logro del Proyecto exportados en la columna oficial de logro de PDF y Word.
- Indicadores de evaluación del Proyecto exportados en la columna oficial de evaluación.
- Prioridad de contextualización docente con respaldo del texto oficial guardado.
- Exclusión de indicadores desmarcados únicamente en la salida, sin pérdida en JSON.
- Pruebas de selección efectiva, texto original/editado, ida y vuelta JSON y composición Word/PDF.
- 68 pruebas automatizadas aprobadas.

## 1.5.1

- JSON v5 con Proyecto persistente por semana y migración de planes anteriores.
- Modalidades curricular, mixta e integrada mediante Proyecto.
- Texto oficial inmutable y contextualización docente conservada por fase.
- Indicadores del Proyecto incorporados en las columnas oficiales de logro y evaluación.
- Instrumentos de evaluación como catálogo interno del prompt, recomendados después de la evidencia.
- Eliminación de hitos, porcentajes y estados automáticos del Proyecto.
- Contratos de prompts ampliados para articular currículo, Proyecto, evidencias e instrumentos.
- 64 pruebas automatizadas aprobadas.

## 1.5.0

- Catálogos versionados de instrumentos y componente Proyecto.
- Indicadores oficiales iniciales de Empatizar, Definir e Idear.
- Contratos estrictos de literalidad, integración de saberes y mediaciones desarrolladas.

## 1.4.1

- Itinerario de preescolar oculto y deshabilitado fuera de Materno Infantil/Transición y `0°`.

## 1.4.0

- Catálogo local de centros sin registros `0000` ni datos personales.
- Rutas oficiales separadas de Preescolar Básico requerido y Óptimo.
- Metodologías activas tratadas como andamiaje continuo en el prompt semestral.

## 1.3.0

- Flujo visual reorganizado según el recorrido docente aprobado.
- Identidad opcional limitada a escudo y lema; el nombre oficial permanece en Centro educativo.
- Contextualización y DUA compactos antes de la proyección semestral.
- Selección por módulo(s), áreas y saberes conceptuales, procedimentales y actitudinales.
- Diagnóstico máximo de dos lecciones, fases editables y distribución flexible por semanas.
- Perfiles de evaluación por ciclo/modalidad con fuente y reglas visibles.
- Prompt semestral ampliado y espacio local para revisar/aprobar la respuesta sin aplicación automática.
- Herramientas de formato contextual y protección de indicadores de logro oficiales.
- Esquema JSON v3 con migración compatible desde v1/v2.
- Puente backend y analítica continúan inactivos y sin red.
- 23 pruebas automatizadas aprobadas.

## 1.2.1-modular.1

- Proyección promovida a etapa principal del flujo, inmediatamente después de Metodología activa.
- Interfaz guiada en cuatro pasos con resumen en vivo y orientación contextual.
- Tarjetas seleccionables para módulos y áreas; buscador y acciones masivas para saberes.
- Distribución adaptable a pantallas pequeñas y foco de teclado reforzado.
- Herramientas de formato, recuperación y reutilización separadas como apoyo secundario.
- Núcleo curricular, guardado/carga, semanas, PDF, Word y portable preservados.

## 1.2.0-modular.1

- Capa avanzada reversible de proyección semestral.
- JSON v2, autoguardado, recuperación e historial local.
- Identidad institucional, contexto/DUA y formato offline.
- Revisión, diagnóstico, estrategias y revisión local de respuesta IA.
- Cobertura, prompt semestral y extensiones de PDF, Word y portable.
- Puente backend/analítica deliberadamente inactivo.
- Datos curriculares y funciones validadas de PIA 1.1.1 conservados.

## Ajuste diagnóstico PNFT–MEP (2026-09-18)
- PIA diferencia antecedentes curriculares PNFT documentados, condiciones de entrada y desempeño real.
- Para Módulo 1 se priorizan antecedentes pertinentes de niveles anteriores; para Módulo 2, antecedentes pertinentes del Módulo 1 del mismo nivel y, solo cuando aporte, niveles anteriores.
- Preescolar conserva separado el itinerario Básico requerido u Óptimo.
- La IA debe justificar cada AP y conservar trazabilidad: antecedente (nivel, módulo, área, saber, indicador) → nuevo aprendizaje → justificación de andamiaje.
- Si no existe antecedente documentado, la salida debe rotularse como condición de entrada por explorar, no como indicador oficial.
- Se conserva la secuencia MEP: determinación de aprendizajes previos → instrumento → implementación → sistematización → análisis → decisiones/recuperación y acompañamiento → socialización/seguimiento.
- Validación: 179/179 pruebas superadas.
