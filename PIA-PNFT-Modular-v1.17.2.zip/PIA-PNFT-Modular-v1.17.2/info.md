# Estado operativo — PIA-PNFT Modular 1.17.2

1 de octubre de 2026, Costa Rica. Respuesta al desbordamiento de plantilla en iOS.

La corrección anterior acotó formularios nuevos, pero la plantilla original seguía con tabla de datos y cuadrículas de tres columnas. Se añade presentación en una columna hasta 760 px, límites de tamaño mínimo y campos de 16 px para prevenir zoom automático de foco en Safari. Se conserva zoom manual, DOM, controles, currículo, guardado, columnas de escritorio y salida impresa. Las tablas comparativas y mapas amplios conservan desplazamiento local.

Fuente, ensamblado, huellas y suite Node se verifican mediante npm test; resultado en `evidence/npm-test-1.17.2.log`. Los 16 archivos protegidos son idénticos a 1.17.1. No se añaden cambios de esquemas o contenidos.

Validación visual iOS: pendiente. Se descargó WebKit para intentar una prueba de layout; no pudo ejecutarse por bibliotecas del entorno y la instalación de dependencias falló. Esto no certifica Safari. Se mantienen las limitaciones de impresión/descargas/IndexedDB nativas de la entrega anterior.

SHA-256 vigente de HTML raíz/web/portable: `a2dc26274c7a460441ea382209953f4160955575849cec08b00dec5aa43ccfcb`.

Guía de funciones: `docs/GUIA_ACTUALIZACION_1.17.0.md`. Informe actual: `docs/INFORME_VALIDACION_V1.17.2.md`.
