# Informe de validación — PIA 1.16.1

Fecha: 1 de octubre de 2026. Base: entrega 1.16.0.

## Resultado

Mapas nuevos ordenados por fase/grupo y semana declarada; semanas visibles en cada saber, grupo y resumen de rama; alturas calculadas para el contenido. Ordenación automática explícita con deshacer/rehacer, sin alterar currículo, asignaciones, confirmación ni huella semántica. La exportación PNG consume el mismo modelo e incluye los rangos.

## Compatibilidad

La migración acepta `pia` y `enhancements`, ambos identificadores de fase (`id` y `phaseId`), posiciones manuales y notas. Conserva la base de distribución histórica cuando existen desplazamientos guardados. La entrada de mapas acepta `pia-route-current-v2` y `pia-route-selected-v1` con huella, resumen, confirmación y deshacer; la entrada de propuestas mantiene v3/v4. El JSON completo continúa usando el cargador del plan.

No se recupera información borrada por un archivo anterior ni estado editable desde PNG. Los datos nuevos de tema/problema y la importación estructurada de Proyecto no se implementan en esta corrección.

## Evidencia

| Verificación | Resultado | Evidencia |
|---|---|---|
| Regresiones Node | 293/293 | `evidence/regression-node-final-1.16.1.log`; verificación de entrega: `evidence/npm-test-1.16.1.log` |
| Históricos: rangos, grupos, posiciones, notas, razones y dos cargas | 6 pruebas | `tests/v1.16.1-route-history.test.mjs` |
| Mapa de 16 saberes y geometría de nodos | Sin colisiones calculadas | `evidence/route-map-layout.json` |
| Etiquetas de semanas y tres etapas | Aprobadas en DOM | `evidence/route-map-jsdom.log` |
| Recuperar ruta/propuesta, cancelar, rechazar huella y deshacer | Aprobadas en DOM | `evidence/route-map-jsdom.log` |
| Autoguardado, JSON y portable con mapa | Aprobados en DOM | `evidence/route-map-jsdom.log` |
| Movimiento de bloques sin obsolescencia semántica | Aprobado en DOM | `evidence/route-map-jsdom.log` |
| PNG incluye semanas | Texto comprobado con sustituto de canvas; no descarga real | `evidence/route-map-jsdom.log` |
| Varios grupos, consulta literal, importación y respaldo | Aprobados en DOM | `evidence/workspace-functional-1.16.1.log` |
| Contenido Word/PDF y reimportación Word | Aprobados en DOM | `evidence/export-dom-1.16.1.log` |
| Datos oficiales, referencias, BASELINE y manifiesto | Sin cambios | `evidence/protected-source-1.16.1.json` |

## Límite de validación

La revisión real en Chrome/Edge, lectura responsive, focos, ventanas nativas, descargas y paginación sigue pendiente por las restricciones de navegador documentadas en 1.16.0. No se ha intentado eludir esa política. Geometría calculada y simulación DOM no equivalen a una certificación visual.

Los dos agentes auxiliares no pudieron iniciar por un límite de uso del servicio. El agente principal realizó la implementación y sus comprobaciones; no se presenta como una doble revisión independiente.

## Integridad

SHA-256 del HTML y copias web/portable:

`d4f752e2a7cda157d5c850c97b20ccd999a403417a62e94d0902ea89a8f91907`

La fuente se conserva en `src/`; las salidas se construyen con `node scripts/build.mjs`. El plan mantiene esquema 6. No se cambia el currículo, el orden del manifiesto ni los exportadores oficiales.
