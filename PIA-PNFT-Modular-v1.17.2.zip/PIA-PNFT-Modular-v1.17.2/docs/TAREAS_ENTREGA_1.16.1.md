# Seguimiento de tareas y dependencias — PIA 1.16.1

| Tarea | Depende de | Estado |
|---|---|---|
| Revisar imagen y modelo anterior | Adjuntos y fuente 1.16.0 | Completada |
| Ordenar mapas nuevos y mostrar semanas | Estado semántico | Implementada |
| Conservar mapas históricos y rangos de fases | Migración v6 | Implementada y probada |
| Cargar mapa guardado con revisión | Huella y esquema conocidos | Implementada y probada |
| Deshacer/rehacer y persistencia | Modelo de presentación | Probados en DOM |
| Primer junior: interfaz | Servicio de agentes | No inició: límite de uso |
| Segundo junior: compatibilidad | Servicio de agentes | No inició: límite de uso |
| Implementación y verificación principal | Fuente integrada | Completadas |
| AGENTS, SPEC, info, guía y acuerdos | Fuente y evidencia | Actualizados |
| Suite Node | Fuente final | 293/293 aprobadas |
| Chrome/Edge, responsividad, impresión y descarga real | Navegador autorizado | Pendientes; entorno bloqueado |
| Temas/problemas comparables y JSON de Proyecto | Acuerdos 2027 | Registrados; implementación pendiente |
| Paquete de entrega | Integridad, pruebas y documentación | Preparado |

Este registro es una tabla local de tareas y dependencias. No afirma ejecución mediante un complemento DOTS ni doble revisión independiente.
