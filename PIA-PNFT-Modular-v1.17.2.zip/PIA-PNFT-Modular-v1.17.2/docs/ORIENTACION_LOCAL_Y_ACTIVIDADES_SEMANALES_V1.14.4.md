# Orientación local y actividades semanales — PIA 1.14.4

## Propósito

Esta ampliación ofrece orientación breve sobre PIA y el PNFT sin API ni transmisión automática de información. También permite registrar por semana decisiones sencillas sobre organización, tipo de actividad y entorno o recurso.

## Asistente local

- Funciona con una base curada incorporada en el HTML.
- Busca por palabras, frases, sinónimos y el contexto general seleccionado en PIA.
- Toda respuesta muestra fuente, páginas, estado de la fuente y confianza de la coincidencia.
- La confianza describe la coincidencia de búsqueda; no certifica una decisión curricular.
- Presenta preguntas relacionadas.
- Incluye ayuda operativa sobre Proyecto, requisitos de la ruta, propuestas y productos, guardado/JSON, mapa/calendario y generación de prompts.
- Ante preguntas sobre Proyecto o apertura de la ruta, revisa la selección visible e indica por separado si falta confirmar el perfil, si el perfil contempla Proyecto, si el componente quedó activado y si existen saberes seleccionados.
- Si no encuentra una coincidencia suficiente o la confianza es baja, no presenta el resultado como seguro: muestra coincidencias relacionadas y prepara una consulta externa revisable.
- Copiar y abrir ChatGPT o Copilot son acciones separadas. Abrir un sitio no envía la consulta.
- No usa `fetch`, API, servidor, telemetría ni almacenamiento de preguntas.

## Plan Nacional y referencias

Al seleccionar **III Ciclo y Ciclo Diversificado Vocacional — Plan Nacional**, PIA abre y destaca el catálogo opcional de indicadores de referencia. No selecciona ni incorpora referencias automáticamente. Toda referencia conserva nivel, módulo, área, saber, texto literal, razón y contextualización, y nunca sustituye los indicadores vigentes.

## Mediación diferenciada

Los prompts solicitan:

1. estrategia común y accesible para el grupo;
2. opciones diferenciadas únicamente según apoyos declarados;
3. alternativas de acceso, participación, representación, acción o expresión;
4. formas equivalentes de evidenciar el aprendizaje;
5. prohibición de nombres, diagnósticos clínicos, expedientes y datos sensibles;
6. respeto exclusivo de orientaciones generales previamente autorizadas cuando se declare una adecuación significativa o PEI aprobada.

PIA no diagnostica, no interpreta una PEI, no aprueba adecuaciones y no reduce automáticamente el currículo.

## Organización y actividad puntual por semana

Cada semana dispone de tres clasificaciones opcionales y una nota breve:

- **Organización:** individual, parejas, equipos, plenaria o estaciones.
- **Tipo de actividad:** exploración, práctica, juego puntual, reto breve, caso, adivinanza, roles, rompecabezas, investigación, diseño, prueba y mejora, presentación o reflexión.
- **Entorno o recurso:** dispositivos/programación, simulación, desconectada, tangible, multimedia o demostración docente.

Estas decisiones no son metodologías. Un juego puntual no equivale a ABJ y un reto breve no equivale a ABR. Los valores se guardan dentro de cada semana en `activityPlanning`, participan en JSON/autoguardado y se incorporan al prompt semanal.

En modo **Curricular**, los selectores de etapa y fase del Proyecto se ocultan visualmente. Sus valores guardados no se borran y vuelven a mostrarse al elegir semana **Mixta** o **Integrada mediante Proyecto**.

## Fuentes iniciales

- *Orientaciones PNFT 2026 — Apoyos educativos*, pp. 8–9, 14–25, 28–35 y 38–43.
- *Lineamientos técnicos para la evaluación de los aprendizajes 2026*, pp. 8–22.
- *Actividades desconectadas en secundaria*, pp. 3–13 y 24–25.
- `AGENTS.md` y `SPEC.md` de PIA 1.14.4.
