# Informe de validación — PIA 1.16.0

Fecha: 1 de octubre de 2026. Base recibida: PIA 1.15.1.

## Resultado de la entrega

Se implementaron las seis vistas, la gestión local de varios planes, el JSON conjunto, el contrato de borradores semanales y la importación revisada Word/JSON. La aplicación conserva el currículo oficial y el esquema v6. Los acuerdos recuperados se documentan íntegramente en `ACUERDOS_ENTREGA_INTERFAZ_1.16.0.md`.

**Estado:** implementación y validación automatizada/DOM aprobadas; revisión visual, impresión y descargas reales en navegador pendientes por bloqueo del entorno. No se presenta esta entrega como una certificación completa en Chrome o Edge.

## Evidencias

| Comprobación | Resultado | Archivo |
|---|---|---|
| Fuente JS/CSS y ausencia de nuevas llamadas de red | Aprobada | `evidence/npm-test-1.16.0.log` |
| Cambios dentro del alcance autorizado | Aprobada | `evidence/npm-test-1.16.0.log` |
| Tres salidas construidas idénticas y versión consistente | Aprobada | `evidence/npm-test-1.16.0.log` |
| Suite Node de regresión | 287/287 | `evidence/npm-test-1.16.0.log` |
| Importación Word/JSON: extracción, literalidad, ZIP y saneamiento | 20/20 | `evidence/word-import-audit.json` |
| Cambiar A/B, exportar/cargar JSON, importar/restaurar, consulta literal | Aprobada en DOM simulado | `evidence/workspace-functional-jsdom.log` |
| Descargar/abrir portable con varios planes | Aprobada en DOM simulado; una sola interfaz y nuevo plan vacío | `evidence/workspace-functional-jsdom.log` |
| Word/PDF: contenido, formato, reflexiones, exclusión de interfaz | Aprobada en DOM simulado | `evidence/export-contracts.json` |
| Word exportado → reconocimiento → incorporación revisada → JSON | Aprobada en DOM simulado | `evidence/export-contracts.json` |
| Catálogos y referencias protegidas comparados con el ZIP original | Sin cambios | `evidence/protected-source-integrity.json` |
| Chrome/Edge visual, ventanas, descarga y paginación real | No ejecutada; entorno bloqueado | Limitación descrita abajo |

## Riesgos corregidos durante la integración

- Duplicación de evaluación del Proyecto al reimportar Word. Se separa para consulta y se conservan los registros de Proyecto del plan.
- Pérdida de filas de mediación de la misma semana. Se concatenan las filas reconocidas; tablas ambiguas/combinadas ofrecen correspondencia manual.
- Advertencia incompleta cuando solo parte del indicador coincidía. Ahora el texto no reconocido permanece visible para revisión.
- Pérdida de listas DOCX. Se conservan como listas semánticas; la numeración avanzada requiere revisión.
- Duplicación del menú al abrir portable. La exportación elimina controles transitorios y reconstruye una única interfaz.
- Contenido heredado al crear grupo nuevo desde portable. Los planes nuevos comienzan vacíos.
- Historial de deshacer y selecciones de texto del grupo anterior. Se despejan al cargar otro planeamiento.
- Consultas nuevas editadas que no se guardaban o se descargaban sin sus cambios. Se conserva el texto exacto por plan.
- Visibilidad indebida del almacén de reflexiones y del popover. Se excluyen del cambio de secciones.
- Compatibilidad con JSON histórico `enhancements`. Se conserva la entrada antes de la migración.

## Límites y verificación aún pendiente

El navegador remoto rechazó el acceso a localhost y su política no permite abrir `file:`. El intento de obtener Chromium local tampoco produjo un ejecutable utilizable. No se intentó eludir la política. Node y JSDOM permitieron comprobar lógica y contenido; no acreditan layout, responsividad real, foco visible, comportamiento de ventanas emergentes, descargas nativas o impresión/paginación.

DOCX admite formato directo de texto y tablas reconocibles. Estilos heredados, imágenes, numeración exacta y tablas complejas requieren revisión manual. El `.doc` binario debe convertirse a `.docx`. Las referencias de otro nivel y los registros de Proyecto no se reconstruyen automáticamente desde un documento desconocido.

Las comprobaciones técnicas no certifican alineamiento pedagógico ni logro del RdA. La selección curricular reconocida en Word permanece opcional; los indicadores se resuelven desde el catálogo y la persona docente confirma la aplicación.

## Integridad de la entrega

SHA-256 del HTML autónomo y de sus copias web/portable:

`d5c76cb8432f92b0afd272d0f15be58ddca09332482481166d7a7c1222adf041`

Los archivos de `src/` constituyen la fuente. `node scripts/build.mjs` genera `index.html`, `dist/web/index.html` y `dist/portable/index.html`. `npm test` ejecuta verificación de fuente, alcance autorizado, integridad y regresiones. Las auditorías DOM adicionales requieren `jsdom` disponible mediante `PIA_JSDOM_PATH` o instalado como herramienta de prueba; no es una dependencia de uso docente.
