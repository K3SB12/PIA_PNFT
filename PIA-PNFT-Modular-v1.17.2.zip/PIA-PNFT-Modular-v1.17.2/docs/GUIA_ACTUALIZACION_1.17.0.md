# Guía de actualización — PIA 1.17.0

## Abrir y conservar trabajo

Descomprima el paquete y abra `index.html` o `dist/portable/index.html`. Para GitHub Pages use `dist/web/index.html`: las tres salidas son idénticas. Conserve la carpeta modular para futuras modificaciones. Antes de sustituir su copia de uso, descargue su JSON de planeamientos; puede cargarlo desde Abrir/Cargar archivo. Se conserva el esquema v6 y la recuperación de mapas históricos de 1.16.1.

Los datos locales pertenecen al navegador y origen donde trabaja. Compartir el HTML base limpio no envía sus grupos. Compartir un portable generado o un JSON del conjunto sí incluye sus planeamientos; revise su contenido. Esta versión no crea colaboración ni sincronización entre asesores.

## Ubicación de funciones

| Ubicación | Función |
|---|---|
| Mis planeamientos → Buscar planeamientos | Nombre/grupo/ciclo, nivel, año y semestre; filtra la lista sin eliminar planes |
| Herramientas generales → Biblioteca | Archivos, vínculos, filtros y asociaciones a semanas del activo |
| Herramientas generales → Panel estadístico | Comparación de ejecución entre grupos, módulos, niveles y ciclos |
| Herramientas generales → Seguimiento curricular | Registro semanal, bitácora, evidencias, relación con RdA/perfil y recuperación |
| Herramientas generales → Plantillas y versiones | Guardar, comparar y restaurar versiones; crear modelos selectivos |
| Herramientas generales → Revisión asesora | Pendientes, salto a la semana, comentarios y respuestas |
| Proyección semestral → Proyecto completo y semanas JSON | Consulta, formato, importación revisada y respaldo |

El menú conserva las seis secciones anteriores. «Menú» permite ocultarlo en escritorio y abrirlo en pantallas pequeñas; «Cerrar menú» y Escape lo cierran. Los controles mantienen etiquetas y navegación por teclado. Conserva el selector de tema existente.

## Proyecto y semanas desde IA

1. Seleccione currículo, perfil de evaluación compatible y Proyecto; confirme el perfil y la ruta con sus ventanas.
2. En las propuestas de ruta, revise tema/situación problema, producto, recursos, conocimientos y tiempo cuando la respuesta los aporta. Los formatos históricos siguen siendo legibles; si no traen estos campos, complete la nueva consulta.
3. Abra Proyecto completo y semanas JSON. «Preparar consulta» genera instrucciones y el catálogo con los IDs/huella del plan. Cópiela a la IA externa de su elección; PIA no se conecta automáticamente. «Descargar formato JSON» aporta la estructura actual.
4. Solicite JSON completo con I. Etapa inicial: Empatizar, Definir, Idear; II. Desarrollo: Prototipar; III. Final: Probar/Evaluar. Una semana puede tener varias fases en `phaseIds`. Para los planes 2027 el problema se define previamente por la asesoría; no se exige su construcción inicial conjunta con estudiantes ni se inventan sus conocimientos.
5. Pegue/seleccione el JSON y pulse Revisar. PIA controla huella, semanas, IDs y ventanas, exige las fases y dos alternativas docentes por fase. El tiempo superior a los bloques declarados queda como advertencia de viabilidad para revisión profesional.
6. Compare contenido actual/recibido y tema, problema, recursos, condiciones y tiempo. Elija campos y semanas; la incorporación pide confirmación y guarda una versión anterior. Saberes e indicadores tienen casilla propia, inicialmente desmarcada.
7. Revise cada semana. Los indicadores oficiales proceden del catálogo; las alternativas de evaluación siguen editables y la primera queda seleccionada. Cambiar etapa o fase manualmente vuelve a una fase seleccionada, conservando sus registros. Restaurar una versión pasa por comparación.

El formato descargado es una estructura para completar; las alternativas vacías no pasan validación. Si cambia currículo, perfil o ruta después de pedir la respuesta, regenere/revise la huella antes de incorporarla.

## Biblioteca de recursos

Guarde una ficha con PDF, DOCX, PPTX o MP4 de hasta 20 MB, o un enlace HTTPS/YouTube. Word y PowerPoint se admiten en sus formatos actuales DOCX/PPTX; no se admiten DOC/PPT antiguos. Clasifique ciclo, nivel, módulo y área; varios valores se separan por coma. Registre autor/fuente, uso, condiciones y estado de revisión.

Los documentos se descargan para abrirlos con su aplicación; MP4 dispone de reproducción local; YouTube abre su vínculo. No hay conversión de documentos ni descarga automática de videos externos. «Vincular al plan activo» asocia una ficha a la semana indicada, visible en Seguimiento.

**Para trasladar archivos, exporte el ZIP de biblioteca**, además del JSON/portable de planes. El JSON del catálogo solo contiene fichas. En otro dispositivo cargue planes y después importe el ZIP: recupera adjuntos faltantes de fichas iguales sin duplicarlas. Si la ficha con ese ID difiere, se informa el conflicto. La importación requiere ZIP exportado por PIA; no admite ZIP arbitrarios/comprimidos. Límite del paquete: 150 MB. La capacidad local depende del navegador.

Eliminar un recurso retira su ficha y adjunto local; conserva las referencias semanales como historial. El ZIP exportado previamente sirve para recuperarlo. Los archivos apenas seleccionados se guardan al confirmar la ficha; los campos escritos del formulario tienen borrador local.

## Avance y seguimiento

En Seguimiento registre estado y minutos previstos/trabajados, fecha, bitácora y evidencia general. Pendiente significa cero minutos registrado; En desarrollo exige minutos entre cero y el total; Completado exige el total. Para dos módulos, distribuya los minutos: las sumas deben coincidir y no repetirse en ambos.

Los minutos corresponden al desarrollo curricular. Una semana completamente diagnóstica no entra en el módulo; una semana con una lección diagnóstica inicia con 40 minutos de desarrollo, revisables. No registrar una semana significa falta de información, no ausencia probada de trabajo. El texto del formulario se conserva como borrador; «Guardar registro» confirma el dato usado en gráficos.

El panel ofrece barras, distribución circular y tablas. Filtre ciclo/nivel/año/semestre/módulo/grupos y fecha de corte. Sin selección de grupos entran todos los del filtro. Muestra minutos previstos, trabajo registrado y grupos aportantes. El consolidado pondera tiempo previsto de los grupos con registros y distribución válida; sus semanas sin registro permanecen en el denominador. Los grupos sin registros se muestran aparte. Sin distribución de los dos módulos no se inventa un porcentaje por módulo. Con corte, registros posteriores o sin fecha no aportan ejecución.

El gráfico describe ejecución declarada, no dominio del RdA. En cada área consulte saberes/indicadores oficiales, competencias, RdA y perfil. Registre si su relación curricular está pendiente, validada por usted o requiere ajuste; documente por separado evidencia y valoración del aprendizaje. Anote necesidades, recuperación y cómo comprobar nuevamente. «Preparar sugerencias» genera un texto orientador local a partir de la necesidad escrita; debe adaptarse al indicador, evidencia, recursos y tiempo. No analiza automáticamente resultados de alumnos.

La tabla compara decisiones/evidencias registradas en grupos y niveles. «Explorar trayectoria» abre el referente curricular de antes/ahora/después que ya tenía PIA. Ninguna relación curricular valida por sí sola el aprendizaje alcanzado.

## Versiones, plantillas y revisión

Guarde hasta diez versiones por plan. «Comparar y restaurar» muestra diferencias de texto/campos (máximo 250); la restauración pide confirmación y respalda el activo. Estas versiones son diferentes del historial del mapa y de los cinco respaldos de limpiar/eliminar, que se conservan.

La plantilla conserva estructura y currículo. Elija si conserva estrategias, ruta, Proyecto, contexto y datos administrativos; previsualice antes de guardar. Se vacían diagnóstico, seguimiento, reflexiones, comentarios y consultas; la ruta requiere nueva confirmación. Sin datos administrativos también se vacía identidad institucional. Hay hasta treinta plantillas. Usar una crea un plan independiente; descargarla permite compartirla.

Revisión detecta vacíos de mediación/evaluación, saberes sin rango/correspondencia, ruta pendiente, tema/problema/fases faltantes y consulta semestral desactualizada cuando existe huella. Los avisos orientan y no son un certificado de calidad. Los accesos llevan a su sección/semana. Agregue comentarios generales o por semana, respuesta y estado; máximo cien por plan.

Los informes de revisión, estadísticas y seguimiento tienen impresión interna separada del formato oficial, con textos de campos incluidos. Se verificó su contenido DOM; todavía falta revisión nativa de impresión, descargas, adjuntos IndexedDB y diseño en Chrome/Edge/móvil.
