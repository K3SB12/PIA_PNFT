# Informe de validación — PIA 1.17.2

Reporte: la plantilla continúa desbordando en iOS. Fecha local: 1 de octubre de 2026, Costa Rica.

## Hallazgo y cambio

1.17.1 limitó anchos de las herramientas nuevas. La tabla de información general y las cuadrículas originales `.areas-rda-container`, `.saberes-grid` y `.tres-columnas` mantenían dos/tres columnas en teléfono. Los controles y tamaños mínimos de contenido podían forzar el ancho disponible. La corrección aplica también a esas estructuras.

Hasta 760 px, la tabla de datos se apila y las cuadrículas pasan a una columna `minmax(0,1fr)`. Cabecera semanal, fieldsets y campos tienen tamaño mínimo cero y ancho máximo del panel. El input de lecciones ya no fuerza 180 px. Controles de edición tienen 16 px para evitar zoom de foco de Safari; no se desactiva zoom manual. La tabla no depende de `:has` ni de que JavaScript le haya asignado una sección.

Todo está limitado a `@media screen`: conserva estructura oficial, controles, edición, guardado y formato de impresión. No se recorta globalmente contenido para esconder desbordamiento. Tablas/mapas amplios siguen con desplazamiento local.

## Verificación

`npm test` verifica fuente, alcance autorizado, ensamblado idéntico, integridad y las 326 pruebas existentes. Evidencia actual: `evidence/npm-test-1.17.2.log`. Los 16 archivos de datos/referencias/BASELINE/manifiesto se compararon byte por byte contra 1.17.1: `evidence/protected-source-1.17.2.json`.

Las pruebas DOM de 1.17.0 siguen siendo evidencia histórica de comportamiento, no validación visual de esta corrección. Se intentó una prueba WebKit; el motor descargado no pudo iniciarse por bibliotecas faltantes y la instalación de dependencias falló (`evidence/webkit-dependencies-1.17.2.log`). No se afirma aprobación de layout WebKit ni Safari/iOS real. Hace falta comprobar la pantalla del usuario y distinguir apertura en Safari o vista previa de Archivos; una vista previa de HTML puede no ejecutar toda la aplicación.

SHA-256 de las tres salidas HTML: `a2dc26274c7a460441ea382209953f4160955575849cec08b00dec5aa43ccfcb`.
