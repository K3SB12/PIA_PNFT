# Informe de validación — PIA 1.17.1

Corrección del reporte de adaptación en celular. Fecha local: 1 de octubre de 2026, Costa Rica.

## Cambio

Las herramientas nuevas tenían etiquetas inline y fieldsets sin límite explícito de tamaño mínimo. Su tamaño intrínseco puede exceder el espacio disponible en pantallas pequeñas. Se acotaron formulario/fieldset/etiquetas/controles al panel, con texto ajustable y controles de ancho completo. Se contiene desplazamiento horizontal de tablas/mapas dentro de su panel sin ocultar contenido globalmente. En pantallas amplias el menú continúa fijo y ocultable; en pantalla pequeña sigue desplegable.

La consulta para JSON semanal aclara que debe incluir todas las semanas enumeradas del esquema. El formato ya enumeraba todas las semanas existentes. Importar conserva la vista previa y la selección parcial; PIA no controla lo que una IA externa responde ni se conecta automáticamente.

## Verificación y límites

Se ejecutan `npm test`: fuente JavaScript, ensamblado idéntico, alcance autorizado, huellas y suite Node de 326 pruebas. Evidencia: `evidence/npm-test-1.17.1.log`. Archivos protegidos/BASELINE/manifiesto comparados byte por byte contra 1.17.0: `evidence/protected-source-1.17.1.json`. No se altera el almacenamiento ni los registros de Proyecto, recursos, estadísticas y seguimiento.

Las comprobaciones DOM de 1.17.0 se conservan como evidencia histórica; no son una nueva certificación visual de esta corrección. No se dispone aquí de verificación de layout real en el celular del usuario. Se entrega corrección de CSS para comprobar en ese dispositivo; falta confirmar su resultado visual y la navegación nativa. El informe 1.17.0 mantiene las limitaciones de impresión/descargas e IndexedDB.

SHA-256 de HTML raíz/web/portable: `ecb2c8811809287ec870bea70895fe417d5ac3024b7d902f100fc8cf4a5b7d07`.
