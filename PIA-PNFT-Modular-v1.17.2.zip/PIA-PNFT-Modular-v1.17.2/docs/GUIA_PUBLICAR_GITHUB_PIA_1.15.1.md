# Publicar la corrección PIA 1.15.1

1. Utilice únicamente el archivo `PIA-PNFT-Modular-v1.15.1.zip`.
2. Extraiga el contenido en una carpeta nueva; no lo mezcle con 1.15.0.
3. Cargue en GitHub Pages los archivos extraídos, incluido `index.html`.
4. Abra la publicación en una ventana privada y confirme que el recorrido identifica **PIA 1.15.1**.
5. Pruebe **Continuar un planeamiento**, cancele una vez y confirme que la portada permanece.
6. Repita la acción, seleccione una copia de un JSON real y confirme que el plan se carga.
7. Pruebe también **Abrir** desde la barra inferior.

No utilice el ZIP como página web: GitHub Pages debe recibir los archivos extraídos.
