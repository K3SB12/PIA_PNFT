# Mapas y recuperación — PIA 1.16.1

## Elegir y organizar

Después de validar y seleccionar una propuesta, PIA acomoda los saberes junto a su fase del Proyecto o su agrupación de lecciones pedagógicas. Dentro de cada conjunto utiliza la semana declarada y el nombre para un orden estable. Calcula la altura del bloque según el texto. No modifica la ruta, las relaciones, las semanas ni los indicadores.

Cada tarjeta muestra semana o rango y, cuando corresponde, el nombre del grupo. Los resúmenes de las ramas conservan las discontinuidades: por ejemplo, «Semanas 4–5, 7», sin convertirlas en «4–7». La ausencia de fecha se muestra como pendiente. El mapa y el PNG usan el mismo modelo.

Las cinco fases se rotulan con las tres etapas: I. Etapa inicial (Empatizar, Definir, Idear), II. Etapa de desarrollo (Prototipar), III. Etapa final (Probar/Evaluar).

«Ordenar mapa automáticamente» recalcula la distribución visual. «Deshacer» recupera las posiciones anteriores; «Rehacer» vuelve a aplicar la ordenación. Mover u ordenar bloques no retira la confirmación de la ruta ni vuelve obsoleto el prompt. Un cambio de fase, semana o relación sí exige revisión semántica.

## Recuperar trabajo de versiones anteriores

| Archivo disponible | Acción | Resultado |
|---|---|---|
| JSON del planeamiento completo, con `pia` o `enhancements` | «Continuar un planeamiento» o «Cargar archivo» | Recupera el plan, las semanas, el contexto y el mapa guardados. |
| JSON de ruta `pia-route-current-v2` | «Cargar mapa guardado» dentro del constructor | Compara la huella y ofrece un resumen antes de restaurar grupos, relaciones, rangos y posiciones. Conserva las semanas del planeamiento. |
| JSON de propuesta elegida `pia-route-selected-v1` | «Cargar mapa guardado» | Recupera la organización elegida y deriva un mapa ordenado; ese archivo no contiene posiciones manuales ni relaciones editadas después de elegir. |
| JSON de propuestas `pia-route-options-v3` o `v4` | «Importar respuesta», validar y seleccionar | Muestra las alternativas y permite elegir para construir el mapa. |
| HTML portable anterior | Abra ese HTML y guarde su JSON; después cárguelo en la versión nueva | Permite trasladar los datos embebidos sin depender de que ambos archivos compartan autoguardado. |
| Solo autoguardado en la versión anterior | Abra la versión anterior y guarde su JSON antes de cambiar | El almacenamiento depende del origen/perfil del navegador; no se promete que otro archivo o navegador pueda encontrarlo. |
| PNG del mapa | Úselo como referencia de consulta | El PNG no incluye el estado editable de PIA. No permite recuperar exactamente decisiones, indicadores, grupos ni vínculos. |

La restauración de un JSON de ruta exige la misma selección curricular y marco temporal; si la huella difiere, PIA conserva el mapa y explica qué debe revisarse. Un JSON completo se carga por el cargador del plan, no por el importador del mapa.

Los mapas históricos con posiciones manuales conservan su base visual anterior. Solo «Ordenar mapa automáticamente» los traslada al diseño nuevo. La carga conserva fases guardadas con `id` o `phaseId`, notas, textos editados, historial y relaciones válidas. Si una versión previa ya eliminó datos al guardar, se necesita una copia anterior que todavía los contenga; PIA no los inventa.

## Alcance pendiente de los acuerdos pedagógicos de 2027

La asesoría podrá definir previamente situación problema, tema, usuarios y producto. La IA deberá ofrecer tres o cuatro propuestas concretas, comparables según recursos, conocimientos docentes/estudiantiles y tiempo; cada propuesta debe explicitar las tres etapas y sus evidencias. Este acuerdo está registrado para la siguiente ampliación del contrato de propuestas. Esta corrección de mapas no incorpora todavía esos nuevos campos estructurados ni los autorrellena.

La importación semanal vigente `pia-weekly-draft-v1` conserva su alcance: mediación, evaluación, recursos y selección curricular opcional. No configura automáticamente título, problema, beneficiarios, etapas ni registros del Proyecto. Su ampliación deberá mantener revisión y conservación de registros existentes.

## Verificación

La suite Node y la auditoría DOM prueban geometría calculada, restauración, cancelación, deshacer/rehacer, huella, autoguardado y portable. No equivalen a revisión visual o impresión real en Chrome/Edge; esa verificación continúa pendiente por las restricciones del entorno.
