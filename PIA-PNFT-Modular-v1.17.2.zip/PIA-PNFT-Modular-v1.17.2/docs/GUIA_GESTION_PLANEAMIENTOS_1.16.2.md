# Gestión de planeamientos — PIA 1.16.2

En **Mis planeamientos → Gestionar planeamiento activo**, revise primero el nombre del plan seleccionado.

| Acción | Resultado |
|---|---|
| Nuevo planeamiento | Agrega una plantilla vacía y conserva todos los planes anteriores. |
| Duplicar para otro grupo | Crea una copia independiente del activo, incluidos sus semanas, contexto, mapa, Proyecto y consultas. Revise grupo, diagnóstico, fechas y condiciones antes de usarla. |
| Descargar JSON solo del activo | Comparte únicamente el planeamiento seleccionado en esquema 6. Excluye otros planes y respaldos de limpieza/eliminación. Incluye el contenido del activo, por lo que debe revisarse antes de compartir. |
| Limpiar contenido del activo | Tras confirmar, vacía datos administrativos, contexto, Proyecto, mapa, consultas y semanas. Conserva nombre e identidad; crea cuatro semanas vacías con los valores iniciales de PIA. |
| Eliminar activo de la lista | Tras confirmar, retira el plan de la lista y del conjunto que se abre automáticamente. Selecciona otro plan. Si era el último, crea una plantilla vacía. |
| Recuperar último respaldo | Tras confirmar, recupera el último plan limpiado o eliminado como un plan separado. No sobrescribe el activo. |

Se conservan los últimos **cinco** respaldos completos de limpieza/eliminación; al recuperar uno, se retira del historial de respaldos. El límite del conjunto es de 30 planes. Si no se puede guardar el respaldo local, la limpieza o eliminación se cancela. Si falla el guardado final, se restituye el contenido anterior y se informa la falla.

**Eliminar de la lista conserva un respaldo recuperable; no es una eliminación definitiva.** Guardar JSON conjunto y descargar la versión offline incluyen todos los planes y sus respaldos de gestión. Para compartir uno, use la descarga individual. Compartir la aplicación limpia no transmite automáticamente el almacenamiento del navegador ni incorpora nuevos datos a otros asesores.

Nuevo planeamiento, cambio de grupo y limpieza sincronizan también respuesta de IA, comparación, mapa y campos ocultos del Proyecto. Los datos de un Proyecto pendiente de confirmación permanecen guardados sin activar su perfil evaluativo.

## Funciones recomendadas para la siguiente entrega

Estas propuestas **no están implementadas en 1.16.2**:

1. **Completar el intercambio de Proyecto con IA.** Comparar propuestas por tema, situación problema, producto, conocimientos previos, recursos y tiempo; validar una y recibir JSON con semanas y etapas I (Empatizar, Definir, Idear), II (Prototipado), III (Probar y evaluar). Previsualizar antes de incorporar. Para los planes 2027, la asesoría define previamente la situación problema, según el acuerdo del usuario. No se modifica el catálogo curricular oficial.
2. **Buscar y filtrar planeamientos.** Nombre, año, semestre, nivel y grupo, con acceso directo al resultado y alcance del filtro evidente.
3. **Comparar versiones del plan completo.** Mostrar cambios en semanas, mapa, Proyecto y consultas antes de restaurar una versión. Recuperar los últimos respaldos no equivale a tener un historial completo de versiones.
4. **Crear plantillas reutilizables.** Elegir qué conservar —estructura, saberes, ruta y estrategias— y qué vaciar —datos del grupo, contexto y resultados diagnósticos—, con una vista previa de lo que se compartirá.
5. **Ampliar la revisión existente.** Ubicar semanas vacías, saberes sin rango, diferencias entre ruta y semanas, etapas incompletas y consultas desactualizadas. Cada observación debe llevar al campo correspondiente y quedar sujeta a decisión docente.

La prioridad es completar Proyecto/JSON: atiende un acuerdo anterior pendiente. La revisión pedagógica sigue a cargo de la persona docente o asesora.

## Validación y alcance

Las pruebas Node y DOM comprueban persistencia, cancelación, aislamiento, recuperación, fallas de almacenamiento y contenido de exportaciones. La revisión visual real en Chrome/Edge y las descargas/impresión nativas siguen pendientes por restricciones del entorno.
