# Informe de validación — PIA 1.14.4

## Alcance

Esta entrega cierra los ajustes del constructor **Ruta curricular del semestre** de III Ciclo y su continuidad hacia el planeamiento. Se verifican el intercambio estructurado con IA externa, persistencia del estado, controles curriculares y temporales, accesibilidad del modal, selección inicial de nivel y tema claro/oscuro.

## Cambios verificados

- Exportación Word alineada geométricamente con la plantilla oficial 2026: Carta horizontal (792 × 612 pt), ancho estable de 701.7 pt y proporciones institucionales para RdA, saberes, planificación semanal y reflexiones. Se evita que títulos o tablas se expandan lateralmente en Microsoft Word.
- Cada propuesta incluye una vista conceptual preliminar por nodos y fases APD antes de aplicar la ruta completa.
- Las métricas distinguen Solo lecciones, Solo Proyecto y Lecciones + Proyecto; se calcula además presencia total en cada momento para evitar interpretar 0 % Solo Proyecto como ausencia del Proyecto.
- La respuesta validada puede descargarse localmente como `.md` y el bloque técnico validado como `.json`.
- El primer clic conserva el nodo del DOM; el doble clic navega a la fila editable sin perder el evento.
- Los bloques del grafo pueden reposicionarse; sus coordenadas se guardan como metadatos visuales acotados y se restauran al volver a abrir, sin alterar el currículo.
- El prompt comparativo puede señalar oportunidades orientadoras de Trabajo cotidiano/Tarea y reserva la recomendación de instrumentos para la mediación semanal.
- El contrato prohíbe estirar `weekStart/weekEnd` para esconder momentos discontinuos.
- I Ciclo inicia en 1.º, II Ciclo en 4.º y III Ciclo en 7.º.
- Tema claro/oscuro persistente mediante `localStorage`.
- Paso 3 denominado **Propuesta de la IA**.
- Entrada equivalente por pegado o archivo `.json`, `.md` o `.txt` local.
- Contrato `pia-route-options-v4`, compatible con v3, con modos de comparación y revisión, huella de selección, propuesta de referencia, validación de identificadores, semanas y cobertura de saberes.
- Protección de Empatizar, Definir, Idear, Prototipar y Probar/Evaluar cuando el Proyecto está activado.
- Una propuesta inválida no reemplaza la ruta vigente; aplicar una propuesta requiere acción explícita.
- Exportación de `Consulta-para-IA.md`, respuesta validada, conjunto de propuestas, propuesta elegida en `.json`, `Ruta-curricular.json` y mapa PNG.
- Persistencia de respuesta, propuesta validada, opción seleccionada, distribución de fases y prompt de estrategias.
- Panel **Continuar con el planeamiento** con proyección semestral y estrategias semana a semana.
- Prompt semanal con Inicio, Desarrollo, Cierre, evidencia, DUA/accesibilidad, diagnóstico declarado, Trabajo cotidiano/tarea, instrumento y ajuste/alerta.
- Doble clic en un saber del mapa para ir a su fila editable y acción **Volver al mapa**.
- El constructor no se cierra al pulsar accidentalmente fuera del panel.
- Barra inferior sin margen negativo y sin superposición sobre la auditoría.
- Word y PDF permiten conservar la salida completa o elegir un rango o semanas específicas. Cada semana mantiene número original, saberes conceptuales/procedimentales/actitudinales, indicadores, estrategias, evaluación y el bloque de reflexión correspondiente al conjunto exportado.
- Cada semana conserva la estructura original de reflexión docente: tres columnas de reflexión y un apartado separado de observaciones/recomendaciones por nivel con el mensaje original. Word/PDF la colocan dentro de esa misma semana. El bloque general repetido se retira de la interfaz y de las exportaciones; los datos históricos siguen siendo legibles al cargar y volver a guardar planes anteriores.
- Se restauró íntegramente **PIA Journey · La Ruta del Docente**, incluido el mapa de progresión curricular o “ruta del tesoro”. Se eliminaron los distintivos técnicos de revisión de la interfaz; el tema oscuro cubre campos, ayudas, saberes, indicadores, tablas, trayectoria curricular, RdA, estados desactivados y foco de teclado.
- La portada incorpora localmente los recursos oficiales MEP, PIA y PNFT, sin filtros de inversión ni dependencia de red.
- El conjunto PNFT de la portada queda transparente, sin tarjeta, “Año 2026” ni pie duplicado; los botones originales se aproximan verticalmente sin cambiar su diseño.
- Explorar un ejemplo, comenzar y continuar son botones completos e independientes, sin flechas que sugieran una secuencia obligatoria.
- El sistema claro/oscuro utiliza variables semánticas y refuerza foco, texto secundario, bordes y nodos del mapa; la selección manual continúa siendo persistente. La evidencia docente aportada permitió cubrir además identidad institucional, campo de asignatura, paneles DUA y referencias, marco curricular, diagnóstico, Proyecto, confirmación evaluativa, pasos y trazabilidad del mapa y controles de semanas.
- La paleta esencial del modo oscuro se comprueba automáticamente con una relación mínima de contraste WCAG AA de 4.5:1 para texto normal.
- Contextualización/DUA e Indicadores de referencia aplican el tema oscuro a sus contenedores, encabezados, textos, campos, tarjetas y avisos, evitando superficies claras residuales.

## Validación visual de la barra

Se ejecutó una prueba de geometría con los estilos reales del modal en 1440×900, 1024×768 y 390×844, simulando zoom de 100 %, 150 % y 200 %. En todos los casos la intersección entre el final de la auditoría y el inicio de la barra fue **0 px**. En 390 px las cuatro acciones se apilan en una columna. El popover contextual se oculta cuando el constructor está abierto.

## Validación automatizada

La batería completa contiene **253 pruebas**. La entrega debe considerarse cerrada únicamente con **253 aprobadas y 0 fallos** en `npm test`.

## Integridad de compilación

Las tres salidas generadas son byte a byte equivalentes:

- `index.html`
- `dist/web/index.html`
- `dist/portable/index.html`

SHA-256 común: `ee435dee4b8c4146f4f1b32cf6e481546c0f3cc13c4ec883ea47535674d1fcc5`

## Criterio de liberación

La versión 1.14.4 conserva el currículo protegido y el esquema de planeamiento existente. Las nuevas funciones organizan, validan, representan y persisten decisiones; no asignan logro al estudiantado, no fijan automáticamente momentos evaluativos y no reemplazan el criterio profesional docente.


## Corrección visual 1.14.4

- La barra de acciones del constructor conserva comportamiento visible en escritorio sin cubrir el contenido de la auditoría.
- En tableta y celular la barra vuelve al flujo normal del modal y organiza los botones en filas, evitando superposición.
- El botón global de ayuda permanece oculto mientras el constructor está abierto.
- Los controles mantienen margen de desplazamiento para navegación con teclado y zoom.


## Cierre de segunda iteración

Se añadieron seis regresiones específicas para: diferenciación estructural de propuestas, matriz completa de comparación, edición detallada por saber, separación táctil entre desplazamiento y movimiento de nodos, explicitación de producto/recursos/puentes/evidencias y contraste de tema oscuro.
