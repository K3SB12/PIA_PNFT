# Informe de validación — PIA 1.17.0

Fecha: 2 de octubre de 2026. Base: 1.16.2 conservada sin modificación.

## Resultado

La actualización de código incorpora menú, Proyecto/JSON, biblioteca, estadísticas, seguimiento, filtros, versiones, plantillas y revisión asesora. El paquete conserva catálogos y las funciones anteriores comprobadas. Esto es una entrega verificada por automatización; no constituye aceptación visual o nativa completa.

| Comprobación | Resultado | Evidencia |
|---|---|---|
| Suite Node completa | 326/326 aprobadas | `evidence/regression-node-1.17.0.log` |
| Biblioteca: formatos/ZIP/CRC, faltantes, cancelación y fallas de guardado | Aprobada con adaptador de almacenamiento | `tests/v1.17.0-resource-library.test.mjs` |
| Proyecto: huella/IDs/fases/ventanas, selección parcial y catálogo | Aprobada | `tests/v1.17.0-project-statistics.test.mjs` |
| Estadísticas: ponderación, no datos/cero, doble módulo y corte | Aprobada | `tests/v1.17.0-project-statistics.test.mjs` |
| Versiones: independencia, límite y rollback; seguimiento sin certificación | Aprobada | `tests/v1.17.0-project-statistics.test.mjs` |
| Herramientas montadas y flujo de Proyecto multifase/editabilidad | Aprobado en DOM sin errores de script | `evidence/verify-v1.17.0-tools-jsdom-1.17.0.log` |
| Seguimiento, borrador sin confirmar, comentarios/respuesta, comparación y plantilla | Aprobados en DOM | `evidence/verify-v1.17.0-tools-jsdom-1.17.0.log` |
| Nuevos campos/versiones/plantillas/catálogo en JSON y portable real | Recuperados en DOM | `evidence/verify-v1.17.0-tools-jsdom-1.17.0.log` |
| Gestión, limpiar/eliminar/cancelar/respaldo, aislamiento y portable | Aprobados en DOM | `evidence/verify-plan-management-jsdom-1.17.0.log` |
| Mapa histórico/ordenación/semanas/rangos/undo y portable | Aprobados en DOM y sustituto de canvas | `evidence/verify-route-map-jsdom-1.17.0.log` |
| Intercambio semanal y recuperación/autoguardado | Aprobados en DOM | `evidence/verify-workspace-jsdom-1.17.0.log` |
| Contenido Word/PDF y reimportación Word | Aprobados en DOM | `evidence/audit-workspace-exports-1.17.0.log` |
| Datos/referencias/BASELINE/manifiesto | 16 archivos idénticos a la base | `evidence/protected-source-1.17.0.json` |
| Fuente, alcance autorizado y huellas de tres salidas | Aprobados por scripts de verificación | `evidence/npm-test-1.17.0.log` |

## Alcance y limitaciones

Las pruebas DOM omiten CSS, usan respuestas simuladas para confirmaciones y sustitutos para descargas/canvas/impresión. Se comprobó que el contenido imprimible de seguimiento y respuestas incluye los textos; falta comprobar paginación y salida nativa. El archivo portable generado se reabrió y recuperó las extensiones, sin asumir que lleve los adjuntos binarios.

Las pruebas de biblioteca usan un adaptador de almacenamiento; verifican bytes e importación/rollback, no cuota/compatibilidad de IndexedDB real. Requiere revisión en Chrome/Edge y dispositivos objetivo, incluyendo abrir archivos, videos, YouTube y transferir el ZIP. La revisión visual real, adaptación móvil, foco/teclado nativos, descarga e impresión no se certifican desde este entorno. No se publicó la actualización.

La suite histórica se conserva; se actualizaron dos verificaciones estructurales para el ensamblado ampliado y el contrato aditivo del Proyecto. El auditor del mapa ajustó su punto de instrumentación a la API ampliada y usa el perfil de secundaria válido. Las comprobaciones nuevas prueban rechazos, límites y comportamiento, no solo presencia de botones.

La integración y cierre de pruebas se realizaron por el agente principal con aporte auxiliar en biblioteca. No se anuncia aprobación independiente de revisores ni aceptación docente final.

## Huella

SHA-256 de `index.html`, `dist/web/index.html` y `dist/portable/index.html`, idénticos: `12be6c7faa6ef7dc5e253c2a88b0f2c6d19346cefb9ad99b4babec5411b94784`. `CURRENT.sha256` identifica el ensamblado; `BASELINE.sha256` no se modificó.
