# Acuerdos recuperados y entrega de la interfaz PIA 1.16.0

Fuente de alcance: conversación adjunta «Markdown pegado(1).md», aprobación «procede con las mejoras», imagen de referencia y autorización de esta continuación. Base: PIA-PNFT Modular 1.15.1. Fecha: 1 de octubre de 2026.

## Acuerdos y resultado

| Acuerdo | Implementación y condición |
|---|---|
| Mantener consulta externa a IA; descartar API de cobro | PIA prepara texto local. No se configura API, clave, servidor o envío automático. |
| Una sección activa al desplazarse | Seis secciones; navegación persistente; ocultar una vista conserva sus controles y datos. |
| Menú y flechas entre planeamientos | Lista, selector, flechas anterior/siguiente y nombre de grupo; conserva nivel, contexto, semanas y prompts por plan. |
| Varios niveles y grupos | Hasta 30 planeamientos locales; un plan nuevo comienza vacío. No crea currículo fuera del catálogo. |
| Guardar JSON conjunto | El JSON mantiene el plan activo v6 y añade `piaWorkspace` con los planes completos. Abrir restaura el conjunto; JSON históricos siguen admitidos. |
| Acentos sutiles PNFT | Línea de colores y bordes en la portada; imágenes oficiales conservadas; etiquetas acompañan el color. |
| Relevancia de la proyección para la IA | Consulta toma ruta, contexto, currículo literal, recursos, metodología, tiempo y evaluación; exige continuidad y decisiones docentes. |
| Formato para rellenar semanas | Contrato `pia-weekly-draft-v1` con huella, número original, referencias exactas y HTML de mediación/evaluación/recursos. |
| Preparar semanas del semestre | Acción docente explícita agrega las semanas faltantes; conserva las existentes y nunca reduce automáticamente. |
| Importar borrador JSON | Verificación de esquema, huella, referencias, campos y numeración; vista previa, selección de semanas/campos/destinos y confirmación. |
| Importar Word exportado por PIA | Reconoce `.doc` basado en HTML y tablas de semanas; añade marcadores técnicos de semana/campo a futuras exportaciones. |
| Importar `.docx` o Word con otra estructura | Extrae XML, formato directo y tablas reconocibles; ofrece correspondencia manual para texto no reconocido. No promete reconstrucción universal. |
| Literalidad curricular y procedencia | Word recibido conserva indicadores para consulta y propone saberes solo por coincidencia literal completa. La selección curricular es opcional y explícita; el texto oficial siempre se resuelve desde el catálogo. |
| Respaldo antes de aplicar | Hasta cinco respaldos de semanas por planeamiento, persistentes en JSON; restauración explícita desde Seguridad y recuperación. |
| Formato enriquecido | Sanea y conserva párrafos, negritas, cursiva, subrayado, listas y paréntesis; DOCX con numeración se presenta como lista de viñetas. |
| Regresión de funcionalidades existentes | Suite Node y pruebas DOM complementarias cubren conservación, importación, prompts, portable y contenido exportado. La validación visual/impresión real queda expresamente identificada. |

## Uso

1. Extraiga el ZIP y abra `index.html`, o publique el contenido de `dist/web/` en su alojamiento habitual.
2. Comience o abra un JSON existente. Seleccione un planeamiento y complete Datos, Contexto y Proyección.
3. Compare las propuestas con las herramientas previas de PIA; ajuste mapa, tabla y calendario y guarde la ruta.
4. En Proyección, prepare explícitamente la estructura de semanas faltantes. Esta operación no desarrolla actividades ni selecciona currículo.
5. Prepare la consulta de semanas a la IA. Revise y edite el texto, cópielo o descárguelo, y consulte externamente.
6. Importe la respuesta JSON o el Word. Compruebe las advertencias y la vista previa. Elija semanas, campos y planes compatibles antes de aplicar.
7. Revise cada semana. Las sugerencias de evaluación permanecen sujetas a decisión docente.
8. Guarde el JSON conjunto para recuperación, o exporte el plan activo con las opciones Word/PDF existentes.
9. Si necesita deshacer una importación, utilice «Restaurar semanas antes de importar» en Seguridad y recuperación.

## Alcance y limitaciones

- Los `.doc` binarios antiguos requieren conversión a `.docx` en Word. El `.doc` HTML exportado por PIA se reconoce directamente.
- En DOCX se recupera formato aplicado directamente; estilos heredados, numeración exacta, imágenes, celdas combinadas y diseños complejos requieren revisión/correspondencia manual. No se afirma equivalencia visual con el documento original.
- El bloque de evaluación del Proyecto en Word PIA queda separado para consulta y no se duplica dentro de la evaluación curricular. Los registros de Proyecto del destino se conservan.
- Los destinos múltiples deben conservar la misma huella de proyección/contexto. Una incompatibilidad cancela toda la aplicación antes de modificar contenido.
- Los indicadores recibidos de Word se muestran para revisión. Los saberes reconocidos requieren selección docente; las coincidencias compartidas se advierten. El importador no interpreta una referencia de otro nivel como currículo actual, ni modifica los registros de referencias autorizadas.
- Los respaldos de importación contienen semanas, no sustituyen el JSON completo. El autoguardado depende de espacio y permisos del navegador.
- La imagen anterior fue una referencia conceptual. Esta entrega implementa los controles descritos, pero no acredita igualdad visual píxel a píxel.
- El entorno no permitió abrir el HTML en un navegador real: localhost fue bloqueado y `file:` no está permitido por la política del navegador. No se intentó evadir el bloqueo. La validación funcional disponible es Node y DOM simulado; no certifica diseño móvil, ventanas emergentes, descargas reales ni paginación/impresión Chrome o Edge.

## Documentación y trazabilidad

`AGENTS.md`: reglas de conservación y excepción autorizada de importación explícita.
`SPEC.md`: contratos funcionales, formatos y límites.
`info.md`: estado operativo y evidencia.
`docs/INFORME_VALIDACION_V1.16.0.md`: resultado de la entrega y comprobaciones.
Los catálogos oficiales, la línea base de referencia y el orden del manifiesto se conservan. No se conecta backend.
