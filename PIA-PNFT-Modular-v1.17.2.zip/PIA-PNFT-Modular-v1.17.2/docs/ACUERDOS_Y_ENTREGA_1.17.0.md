# Acuerdos y entrega — PIA 1.17.0

Fecha: 2 de octubre de 2026. Base conservada: 1.16.2.

| Acuerdo de la conversación | Resultado entregado |
|---|---|
| Mantener funcionalidad y currículo oficial | Fuentes protegidas comparadas, salidas regeneradas y regresiones de gestión/mapas/semanas/exportación ejecutadas |
| Tema y problema para escoger proyectos viables | Contrato de propuestas ampliado y campos de Proyecto con producto, recursos, conocimientos y tiempo; vista de revisión |
| Planes 2027 preparados por asesoría | Consulta expresa problema previamente definido; omite obligación de construirlo inicialmente con estudiantes |
| Tres etapas evidentes y semanas autorrellenables | JSON revisado con cinco fases, varias por semana, vista previa y selección antes de aplicar |
| Orden automático, semanas en mapas y recuperación histórica | Conserva la corrección 1.16.1 y la recuperación con revisión, sin sustituir posiciones históricas silenciosamente |
| JSON completo, búsqueda, versiones, plantillas y pendientes | Implementados en sus herramientas y documentados en la guía actual |
| Biblioteca por ciclo y nivel | PDF/DOCX/PPTX/MP4, HTTPS/YouTube, clasificación y referencias semanales; ZIP de archivos |
| Progresión y relación con RdA/perfil, con recuperación | Fuentes oficiales, comparación curricular previa y tabla de decisiones/evidencias, validación docente y sugerencias orientadoras |
| Estadísticas del módulo y de varios grupos | Minutos declarados por grupo/nivel/ciclo, filtros y gráficos con denominador explícito; no porcentaje automático de aprendizaje |
| Menú con mejor CSS | Herramientas generales y secciones del activo; colapso/panel móvil, etiquetas, foco y teclado |
| No confundir limpiar y eliminar | Se conservan confirmaciones, cinco respaldos y recuperación como plan independiente de 1.16.2 |
| Informar con honestidad el estado | Informe de pruebas y limitaciones nativas incluidas; no se anuncia publicación ni revisión visual certificada |

Esta entrega implementa las funciones anteriores. No incluye sincronización entre asesores, expedientes individuales, lectura automática de evidencias/diagnósticos, API de IA, editor nuevo de instrumentos ni reprogramación automática por feriados. Estas últimas son posibles extensiones, no funciones verificadas en esta versión.

El borrador de consulta debe llevarse manualmente a la IA externa y su JSON debe devolverse a PIA. Una propuesta curricular no demuestra competencia alcanzada: esa valoración requiere evidencias y criterio docente.

Se aporta paquete modular, HTML idéntico para web/portable, código fuente, guías, AGENTS/SPEC/info, historial, pruebas y huellas. La entrega de código está verificada por automatización; la aceptación visual/nativa sigue pendiente según el informe.
