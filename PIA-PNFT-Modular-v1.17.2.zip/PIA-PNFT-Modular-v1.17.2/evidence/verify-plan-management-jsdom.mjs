// Functional DOM audit only. Native browser layout, downloads and print are not certified.
import {createRequire} from 'node:module';
import {readFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const require=createRequire(import.meta.url),{JSDOM,VirtualConsole}=require(process.env.PIA_JSDOM_PATH||'jsdom');
const html=(await readFile(new URL('../index.html',import.meta.url),'utf8')).replace(/<style[\s\S]*?<\/style>/g,'');
const errors=[],downloads=[],blobs=[];
async function open(source,url,storage={}){
  const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
  const dom=new JSDOM(source,{url,runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){w.alert=()=>{};w.confirm=()=>true;w.prompt=()=> 'Grupo B';w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=()=>{};w.Blob=Blob;w.URL.createObjectURL=b=>{blobs.push(b);return 'blob:managed-'+(blobs.length-1);};w.URL.revokeObjectURL=()=>{};w.HTMLAnchorElement.prototype.click=function(){downloads.push(this.download);};Object.entries(storage).forEach(([k,v])=>w.localStorage.setItem(k,v));}});
  await new Promise(r=>dom.window.addEventListener('load',r,{once:true}));
  await new Promise(r=>setTimeout(r,350));return dom;
}
const dom=await open(html,'https://pia-management.local/'),w=dom.window,d=w.document,run=code=>w.eval(code),get=()=>JSON.parse(JSON.stringify(run('obtenerDatosPlan()'))),click=id=>d.getElementById(id).click(),load=plan=>run('cargarPlan('+JSON.stringify(plan)+',{silent:true})');
const select=id=>{d.getElementById('piaPlanPicker').value=id;d.getElementById('piaPlanPicker').dispatchEvent(new w.Event('change',{bubbles:true}));};
let original=get();delete original.piaWorkspace;original.informacionGeneral.ciclo='III Ciclo';original.informacionGeneral.nivel='8°';original.metodologiaActiva='APD';original.pia.context.group='GRUPO A';original.pia.evaluation.projectPlanning.title='PROYECTO A';original.pia.routeMap.aiExchange.responseText='RESPUESTA A';original.pia.aiPrompts.semester='PROMPT A';original.pia.projection.modules=['Módulo 1'];original.pia.projection.areas=['Apropiación tecnológica y Digital'];original.pia.projection.conceptIds=run("PIAProjectionCore.listConcepts(PNFT_DATA,'8°',['Módulo 1'],['Apropiación tecnológica y Digital'])").slice(0,2).map(c=>c.id);original.semanas[0].actividades='<p><strong>MEDIACIÓN A (literal)</strong></p>';load(original);
assert.equal(get().pia.evaluation.projectPlanning.title,'PROYECTO A');assert.equal(d.getElementById('piaProjectPlanningWrap').hidden,true);original.pia.evaluation.confirmed=true;original.pia.evaluation.profileId='secondary';original.pia.evaluation.projectPlanning.enabled=true;load(original);assert.ok(d.querySelectorAll('input[name="piaProjectIndicator"]:checked').length>0);
const first=get().piaWorkspace.activeId;
assert.equal(d.getElementById('piaRouteAIResponse').value,'RESPUESTA A');d.getElementById('piaRouteAIResponse').focus();click('piaAddPlan');
assert.equal(d.getElementById('piaRouteAIResponse').value,'');assert.equal(d.getElementById('piaRouteProposalSummary').innerHTML,'');assert.equal(d.querySelectorAll('[data-pia-route-row]').length,0);assert.equal(get().pia.evaluation.projectPlanning.title,'');assert.equal(get().pia.context.group,'');assert.equal(get().pia.evaluation.projectPlanning.selectedIndicatorIds.length,0);assert.equal(d.querySelectorAll('input[name="piaProjectIndicator"]').length,0);
const second=get().piaWorkspace.activeId;d.getElementById('observaciones').value='GRUPO B SECRETO';select(first);assert.equal(d.getElementById('piaRouteAIResponse').value,'RESPUESTA A');assert.equal(get().pia.evaluation.projectPlanning.title,'PROYECTO A');
console.log('PASS new/switch refreshes AI response, proposals, map, project and context; active editor cannot leak prior text');
w.prompt=()=> 'Copia A';click('piaDuplicatePlan');const duplicate=get().piaWorkspace.activeId;assert.notEqual(duplicate,first);assert.equal(get().semanas[0].actividades,original.semanas[0].actividades);run("semanas[0].actividades='SOLO COPIA'");select(first);assert.equal(get().semanas[0].actividades,original.semanas[0].actividades);select(duplicate);assert.equal(get().semanas[0].actividades,'SOLO COPIA');
click('piaExportActivePlan');assert.ok(downloads.at(-1).endsWith('.json'));const individual=JSON.parse(await blobs.at(-1).text());assert.equal(individual.piaWorkspace,undefined);assert.equal(individual.semanas[0].actividades,'SOLO COPIA');assert.ok(!JSON.stringify(individual).includes('GRUPO B SECRETO'));
console.log('PASS duplicate edits are independent; active JSON excludes other plans and management recovery');
w.confirm=()=>false;click('piaClearActivePlan');click('piaDeleteActivePlan');assert.equal(get().piaWorkspace.plans.length,3);assert.equal(get().semanas[0].actividades,'SOLO COPIA');
w.confirm=()=>true;click('piaClearActivePlan');assert.equal(get().semanas[0].actividades,'');assert.equal(d.getElementById('piaRouteAIResponse').value,'');assert.equal(d.querySelectorAll('[data-pia-route-row]').length,0);assert.equal(get().piaWorkspace.recovery.length,1);assert.equal(d.getElementById('piaRestoreManagedPlan').disabled,false);
const stored=Object.fromEntries(Array.from({length:w.localStorage.length},(_,i)=>{const key=w.localStorage.key(i);return [key,w.localStorage.getItem(key)];}));
const reopened=await open(html,'https://pia-managed-reopen.local/',stored);reopened.window.document.getElementById('piaRestoreManagedPlan').click();const recovered=reopened.window.eval('obtenerDatosPlan()');assert.equal(recovered.semanas[0].actividades,'SOLO COPIA');assert.equal(recovered.pia.routeMap.aiExchange.responseText,'RESPUESTA A');assert.equal(recovered.piaWorkspace.plans.length,4);reopened.window.close();
click('piaRestoreManagedPlan');assert.equal(get().semanas[0].actividades,'SOLO COPIA');assert.equal(d.getElementById('piaRouteAIResponse').value,'RESPUESTA A');assert.equal(get().piaWorkspace.recovery.length,0);
click('piaDeleteActivePlan');assert.equal(get().piaWorkspace.plans.length,3);assert.equal(get().piaWorkspace.recovery.length,1);assert.ok(!get().piaWorkspace.plans.some(p=>p.name.includes('recuperado')));assert.equal(get().piaWorkspace.plans.find(p=>p.id===second).plan.observaciones,'GRUPO B SECRETO');
console.log('PASS cancel, clear, deletion, restoration and local reopening preserve other groups');
const exported=get();load(exported);assert.equal(get().piaWorkspace.recovery.length,1);run('descargarVersionPortable()');const portable=await blobs.at(-1).text();
const opened=await open(portable,'https://pia-managed-portable.local/');const pg=()=>JSON.parse(JSON.stringify(opened.window.eval('obtenerDatosPlan()')));assert.equal(pg().piaWorkspace.plans.length,3);assert.equal(pg().piaWorkspace.recovery.length,1);
for(const id of ['piaClearActivePlan','piaDeleteActivePlan','piaRestoreManagedPlan','piaDuplicatePlan','piaExportActivePlan'])assert.equal(opened.window.document.querySelectorAll('#'+id).length,1);
opened.window.document.getElementById('piaRestoreManagedPlan').click();assert.equal(pg().piaWorkspace.plans.length,4);assert.equal(pg().semanas[0].actividades,'SOLO COPIA');assert.equal(pg().piaWorkspace.recovery.length,0);assert.equal(opened.window.document.getElementById('piaRestoreManagedPlan').disabled,true);
console.log('PASS JSON conjunto and portable retain recovery; controls initialize exactly once');
assert.deepEqual(errors,[]);console.log('PASS no JavaScript DOM errors');opened.window.close();dom.window.close();
