# Revisión independiente de importación Word / JSON

Se revisó `src/application/workspace/workspace.js` sin editar su código. Los documentos en `evidence/word-import-fixtures/` contienen datos sintéticos de prueba; no constituyen currículo añadido a PIA.

## Cobertura reproducible

El harness `evidence/audit-word-import.mjs` ejecuta la API real de importación en un DOM simulado. Requiere Node y jsdom, suministrado mediante `PIA_JSDOM_PATH` cuando no esté instalado en el proyecto. La evidencia legible por máquina se guarda en `evidence/word-import-audit.json`.

Se verifican: huella del borrador, ids de catálogo, semana original, duplicados, límite de semanas, campos obligatorios, DOCX con ZIP almacenado y comprimido, Word HTML de exportación PIA, formato enriquecido, protección de Proyecto, advertencias de literalidad y correspondencia manual.

## Hallazgos iniciales y correcciones recomendadas

| Hallazgo | Efecto | Corrección |
|---|---|---|
| Evaluación Word incorpora `.project-export-block` en evaluación curricular | Proyecto se duplica en posteriores exportaciones | Separar el bloque en la vista consultiva, conservar registros de Proyecto vigentes y excluir el bloque de la aplicación curricular |
| DOCX `w:numPr` se convierte a viñeta textual | Se pierde la estructura editable de lista | Agrupar párrafos consecutivos de lista en `ul`/`li`; declarar limitación si no se lee `numbering.xml` para distinguir lista numerada |
| Un indicador coincidente oculta otro texto adulterado | La advertencia de procedencia resulta incompleta | Revisar todos los párrafos de logro recibidos y advertir texto no reconocido; nunca incorporarlo como currículo oficial |
| Una segunda fila de la misma semana se omite | Puede perderse parte de la mediación al aplicar | Concatenar filas de semana inequívoca o exigir correspondencia manual; conservar el texto extraído completo |

## Resultado de correcciones verificadas

Tras el ajuste realizado por el desarrollador senior, los 20 casos del harness pasan (20/20). Las cuatro incidencias de la tabla quedaron corregidas en la fuente revisada. Se añadieron cuatro pruebas independientes sin dependencias DOM en `tests/workspace-import-contracts.test.mjs` y pasaron (4/4): contrato JSON y extracción ZIP/DOCX.

## Contratos verificados

- El JSON rechaza huellas obsoletas, ids desconocidos, semanas fuera de rango, duplicadas y campos incompletos.
- `.doc` HTML de PIA identifica correctamente semanas 1 y 3, preservando la numeración original sin renumerar por selección.
- `.docx` con ZIP almacenado y deflate funciona en Node 24; conserva negrita, cursiva, subrayado directos, paréntesis y caracteres escapados.
- Una referencia de semana en rango ambiguo permanece para correspondencia manual.
- Un `.doc` binario produce instrucciones de conversión a `.docx`.
- Los indicadores de Word se presentan para consulta; proponen referencias del catálogo únicamente por coincidencia completa para selección docente opcional; no escriben textos oficiales recibidos.
- La importación JSON resuelve `saberRefs`, nombres e indicadores desde el catálogo seleccionado; no utiliza textos oficiales reescritos por la respuesta externa.
- La importación modifica únicamente campos seleccionados y conserva Proyecto, reflexión y demás datos semanales mediante la copia del plan.

## Límites de esta evidencia

Un DOM simulado no acredita descarga, impresión, funcionamiento visual o apertura local en Chrome/Edge. El harness no cubre formato heredado de estilos Word, numeración OOXML avanzada, dibujos, ecuaciones, cuadros flotantes o estructuras de tabla complejas. La aplicación debe mostrar estas limitaciones y facilitar correspondencia manual cuando no reconozca una semana; no se atribuye compatibilidad Word universal.

La prueba adicional comprueba separación del Proyecto por encabezado al convertir un Word y perder las clases HTML. La prueba de exportación/importación en DOM comprueba aplicación revisada y restauración JSON con selección curricular opcional y literal.
