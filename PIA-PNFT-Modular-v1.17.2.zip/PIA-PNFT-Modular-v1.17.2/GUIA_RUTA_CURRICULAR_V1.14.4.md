# Guía de la ruta curricular — PIA 1.14.4

## Propósito

El constructor de rutas organiza **una sola proyección curricular** de III Ciclo. El mapa, el calendario, la tabla y los prompts representan la misma ruta; no son planeamientos independientes.

## Flujo recomendado

1. Seleccione ciclo, nivel, módulo, áreas y saberes.
2. Defina contexto, diagnóstico cuando corresponda, recursos, DUA/accesibilidad y perfil de evaluación.
3. Abra **Organizar ruta y ver mapa**.
4. Revise **Punto de partida** y **Proyecto**.
5. En **Propuesta de la IA**, elija una de dos rutas de entrada:
   - **Pegar respuesta completa de la IA** en Markdown y pulsar **Validar y mostrar propuestas**.
   - **Importar respuesta** como `.json`, `.md` o `.txt`.
6. Compare las propuestas en lenguaje docente. Los datos JSON quedan en **Datos técnicos (opcionales)**.
7. Pulse **Usar esta propuesta como borrador** únicamente en la alternativa que desea llevar al mapa.
8. Revise y ajuste agrupaciones, semanas, fases, relaciones y evidencias. Puede mover los bloques; la distribución visual se guarda con el plan sin modificar el currículo. Un doble clic en un saber del mapa lo lleva a su fila editable; **Volver al mapa** retorna al gráfico.
9. Pulse **Guardar ruta**.
10. Continúe con **Generar proyección semestral** o **Solicitar estrategias semana a semana**.

## Qué puede compartir con una IA externa

PIA permite descargar:

- `Consulta-para-IA-<nivel>.md`: instrucciones, contexto y contrato legible.
- `Ruta-curricular-<nivel>.json`: estructura exacta de la ruta vigente.
- `Propuestas-validadas-<nivel>.json`: todas las opciones comprobadas por PIA.
- `Propuesta-elegida-<nivel>.json`: la alternativa aplicada como borrador, con su identificador estable.
- `Mapa-ruta-curricular-<nivel>.png`: representación visual del mapa.

PIA no envía estos archivos automáticamente. La persona docente decide qué compartir.

## Ajustar una propuesta sin perder su identidad

1. Aplique como borrador la propuesta que desea revisar.
2. Descargue **Propuesta elegida (.json)** si desea conservar una copia o adjuntarla a la conversación con la IA.
3. Use **Solicitar ajustes de la propuesta elegida**. PIA incluirá el identificador y la instantánea exacta de esa alternativa, no solo su letra o título visible.
4. Explique los cambios deseados sin borrar la consulta preparada por PIA.
5. Pegue la respuesta completa o importe el archivo devuelto. PIA solo aceptará la revisión si `parentOptionId` y `revisionOf` corresponden a la propuesta elegida y si se conservan currículo, tiempo y fases requeridas.

La IA puede explicar la propuesta en lenguaje docente, pero debe conservar entre `PIA_DATOS_INICIO` y `PIA_DATOS_FIN` el bloque técnico completo. Así la persona docente puede leer la explicación y PIA puede reconstruir el mapa y el calendario.

## Protección al importar

PIA comprueba el esquema `pia-route-options-v4` y conserva compatibilidad con v3. Verifica la huella de la selección actual, identificadores de saber permitidos, cobertura de todos los saberes, semanas dentro del periodo y las cinco fases de Pensamiento de Diseño cuando existe Proyecto. Al solicitar ajustes, envía la instantánea y el identificador de la propuesta elegida; la IA debe responder con `parentOptionId` y `revisionOf` para evitar mezclar alternativas. Si la respuesta no corresponde al estado actual, contiene referencias desconocidas o está incompleta, no reemplaza la ruta.

## Proyecto y Pensamiento de Diseño

Cuando el Proyecto está activado, las propuestas deben conservar **Empatizar → Definir → Idear → Prototipar → Probar/Evaluar**. PIA alerta si Probar/Evaluar no queda relacionado con un saber, indicador o evidencia pertinente. Las fases pueden coexistir con mediación curricular en una misma semana sin duplicar el tiempo.

## Porcentajes de la propuesta

Los porcentajes visibles describen **organización curricular de los saberes** entre lecciones, Proyecto e integración. No representan participación, aprendizaje alcanzado, calificación ni desempeño del estudiantado.

## Estrategias semana a semana

El prompt de continuidad utiliza la ruta guardada y solicita una matriz con:

`Semana | Saberes e indicadores | Función o fase | Inicio | Desarrollo | Cierre | Evidencia | DUA y accesibilidad | Trabajo cotidiano / tarea | Instrumento sugerido | Ajuste o alerta`

El Trabajo cotidiano se trata como proceso formativo cuando corresponda y no como obligación semanal. Las tareas se proponen para reforzar aprendizajes ya mediados. Las ventanas bimestrales son orientadoras: la persona docente confirma, modifica o descarta cualquier sugerencia.

## Barra inferior y accesibilidad

La barra final contiene, en este orden: **Guardar ruta**, **Generar proyección semestral**, **Solicitar estrategias semana a semana** y **Cerrar**. Ya no utiliza margen inferior negativo y reserva su propio espacio. En pantallas pequeñas las acciones se apilan para no cubrir la auditoría. El constructor no se cierra por un clic accidental fuera del panel.

## Tema claro y oscuro

El control de sol/luna cambia entre tema claro y oscuro y conserva la preferencia en el navegador. El tema no modifica el contenido del planeamiento ni el archivo JSON.

## Exportar semanas a Word o PDF

Al abrir **Exportar**, la opción predeterminada sigue siendo **Todo el semestre**. También puede elegir:

- **Un rango continuo**, por ejemplo semanas 1–4 para un mes o 1–8 para un bimestre.
- **Semanas específicas**, cuando necesita imprimir únicamente determinadas semanas.

La vista previa conserva la numeración original y muestra, para cada semana elegida, saberes conceptuales, procedimentales y actitudinales, indicadores de logro, estrategias de mediación e indicadores de evaluación. Si activa **Reflexiones docentes**, también incorpora qué funcionó, qué no funcionó, qué puede mejorar y las observaciones del conjunto exportado. Desde la vista previa puede imprimir o guardar en PDF; en Word puede guardar el documento o imprimirlo.
