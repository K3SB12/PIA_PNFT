import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';
const root=resolve(import.meta.dirname,'..');
const source=await readFile(resolve(root,'src/application/workspace/workspace.js'),'utf8');
function importer(){
 const context=vm.createContext({document:{addEventListener(){}},PIAProjectionCore:{escapeHtml:String},PIAEnhancements:{getState:()=>({methodology:{}}),exchangeFingerprint:()=> 'test-route-v1',selectedConcepts:()=>[{id:'test-concept',module:'Módulo 1',area:'ATD',name:'Computadora',indicators:['Indicador literal.']}]},semanas:[{},{},{}],TextDecoder,DataView,Uint8Array,Blob,DecompressionStream});
 vm.runInContext(source+'\nglobalThis.api=PIAWorkspace;',context);return context.api;
}
const validWeek=()=>({weekNumber:3,conceptIds:['test-concept'],mediationHtml:'<p><strong>Inicio</strong> (10 minutos)</p>',evaluationHtml:'<ol><li>Evidencia observable</li></ol>',resourcesHtml:'<p>Equipo compartido</p>'});
const draft=weeks=>({schema:'pia-weekly-draft-v1',fingerprint:'test-route-v1',weeks});
test('El borrador conserva semana original, formato y referencia curricular sin aceptar texto oficial de IA',()=>{
 const row=importer().normalizeDraft(draft([validWeek()])).rows[0];assert.equal(row.weekNumber,3);assert.equal(row.conceptIds[0],'test-concept');assert.equal(row.mediationHtml,validWeek().mediationHtml);assert.equal(row.evaluationHtml,validWeek().evaluationHtml);
});
test('El borrador rechaza huella obsoleta, ids desconocidos y numeración inválida sin aceptar el documento',()=>{
 const api=importer();assert.throws(()=>api.normalizeDraft({...draft([validWeek()]),fingerprint:'stale'}),/huella/);
 for(const patch of [{weekNumber:0},{weekNumber:4},{weekNumber:'1'},{conceptIds:['invented']},{evaluationHtml:null}])assert.throws(()=>api.normalizeDraft(draft([{...validWeek(),...patch}])));
 assert.throws(()=>api.normalizeDraft(draft([validWeek(),validWeek()])),/repetida/);
});
test('DOCX ZIP almacenado y deflate extraen el XML íntegro del documento',async()=>{
 const api=importer(),expected=await readFile(resolve(root,'evidence/word-import-fixtures/document.xml'),'utf8');
 for(const filename of ['PIA-docx-stored.docx','PIA-docx-deflated.docx']){
  const bytes=await readFile(resolve(root,'evidence/word-import-fixtures',filename));const arrayBuffer=bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength);
  assert.equal(await api.unzipDocument(arrayBuffer),expected);
 }
});
test('DOCX truncado o sin documento se rechaza en vez de aplicar contenido',async()=>{
 const api=importer();await assert.rejects(()=>api.unzipDocument(new Uint8Array([0,1,2,3]).buffer),/DOCX/);
 const bytes=await readFile(resolve(root,'evidence/word-import-fixtures/PIA-docx-stored.docx'));const truncated=bytes.subarray(0,bytes.length-60);await assert.rejects(()=>api.unzipDocument(truncated.buffer.slice(truncated.byteOffset,truncated.byteOffset+truncated.byteLength)));
});
