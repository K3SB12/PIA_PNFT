import vm from 'node:vm';
import {readFile} from 'node:fs/promises';

const read=path=>readFile(new URL('../../'+path,import.meta.url),'utf8');
export const clone=value=>JSON.parse(JSON.stringify(value));
export async function harness({embedded,storage={}}={}){
  const ids=new Map(),values=new Map(Object.entries(storage)),events={};
  function node(id=''){
    const n={id,value:'',textContent:'',hidden:false,children:[],dataset:{},classList:{remove(){},add(){}},focus(){},matches(){return false;},querySelector(){return null;},querySelectorAll(){return [];},prepend(child){this.children.unshift(child);},after(){},append(){},insertBefore(){},remove(){ids.delete(this.id);},setAttribute(){},replaceChildren(){},click(){}};
    Object.defineProperty(n,'innerHTML',{get(){return this.html||'';},set(html){this.html=html;for(const match of html.matchAll(/id="([^"]+)"/g))if(!ids.has(match[1]))ids.set(match[1],node(match[1]));}});
    return n;
  }
  const root=node();
  for(const id of ['piaProjection','piaReview','metodologiaActiva','metodologiaPersonalizada','metodologiaPersonalizadaContainer','observaciones'])ids.set(id,node(id));
  const document={getElementById:id=>ids.get(id),querySelector:selector=>selector==='.container'?root:selector==='.pia-tools'?node():null,querySelectorAll(){return [];},createElement(){const n=node();Object.defineProperty(n,'id',{get(){return this.key||'';},set(id){this.key=id;ids.set(id,this);}});return n;},addEventListener(type,fn){(events[type]||=[]).push(fn);},body:{append(){}}};
  let current={schemaVersion:6,informacionGeneral:{nivel:'7°',ciclo:'III Ciclo',leccionesPlanificadas:'2'},ejesTransversales:[],metodologiaActiva:'APD',observaciones:'Notas iniciales',semanas:[{id:1,actividades:'<p>Texto inicial</p>'}],pia:{aiPrompts:{semester:'Prompt literal'}}};
  const context=vm.createContext({document,console,Date,Math,JSON,Set,Map,structuredClone,setTimeout(){return 1;},clearTimeout(){},prompt(){return 'Grupo nuevo';},alert(){},mostrarMensaje(){},localStorage:{getItem:key=>values.get(key)||null,setItem(key,value){values.set(key,value);},removeItem(key){values.delete(key);}},PIAProjectComponentCatalog:{defaultWeekProject:()=>({mode:'curricular',stageId:'',phaseId:'',records:{}})},PIAEnhancements:{getState:()=>current.pia,exchangeFingerprint:()=>'same',selectedConcepts:()=>[{id:'saber-1'}]},semanas:clone(current.semanas),obtenerDatosPlan(){return {...clone(current),semanas:clone(context.semanas),metodologiaActiva:ids.get('metodologiaActiva').value,observaciones:ids.get('observaciones').value,fechaGuardado:new Date().toISOString()};},cargarPlan(plan){current={...current,...clone(plan)};if(plan.semanas.length)context.semanas=clone(plan.semanas);if(plan.metodologiaActiva)ids.get('metodologiaActiva').value=plan.metodologiaActiva;if(plan.observaciones)ids.get('observaciones').value=plan.observaciones;},reconstruirVistaSemanasPreservandoContenido(){},nuevoPlan(){}});
  context.window={__PIA_EMBEDDED_PLAN__:embedded,alert(){},addEventListener(){},scrollTo(){}};
  ids.get('metodologiaActiva').value='APD';ids.get('observaciones').value='Notas iniciales';
  const source=(await read('src/application/workspace/workspace.js')).replace('return {snapshot,','return {testInit:init,snapshot,switchPlan,persist,addPlan,prepareWeeks,request,clearActivePlan,deleteActivePlan,duplicatePlan,restoreManagedPlan,activePayload,validStore,');
  vm.runInContext(await read('src/domain/projection/projection-core.js'),context);
  vm.runInContext(source+'\nglobalThis.workspace=PIAWorkspace;',context);
  context.workspace.testInit();
  return {context,workspace:context.workspace,ids,values};
}
