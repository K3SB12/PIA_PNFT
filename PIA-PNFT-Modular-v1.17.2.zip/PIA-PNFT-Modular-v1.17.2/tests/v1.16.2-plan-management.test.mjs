import test from 'node:test';
import assert from 'node:assert/strict';
import {harness,clone} from './support/workspace-harness.mjs';
const stable=x=>JSON.parse(JSON.stringify(x,(key,value)=>['fechaGuardado','updatedAt'].includes(key)?undefined:value));

test('cancelar limpieza y eliminación conserva contenido, lista y respaldos',async()=>{
  const {context,workspace}=await harness();context.confirm=()=>false;
  const before=stable(workspace.snapshot());workspace.clearActivePlan();workspace.deleteActivePlan();
  assert.deepEqual(stable(workspace.snapshot()),before);
});

test('limpiar conserva identidad y nombre, respalda todo y deja intacto otro plan',async()=>{
  const {context,workspace,values}=await harness();context.confirm=()=>true;
  const initial=workspace.snapshot().activeId;workspace.addPlan();const second=workspace.snapshot().activeId;
  workspace.switchPlan(initial);const original=clone(workspace.activePayload());
  original.pia.context={group:'CONTEXTO ORIGINAL'};original.pia.evaluation={projectPlanning:{title:'PROYECTO ORIGINAL'}};original.pia.routeMap={aiExchange:{responseText:'RESPUESTA ORIGINAL'}};original.piaWeeklyDraftPrompt='CONSULTA ORIGINAL';context.cargarPlan(original);
  const before=stable(workspace.snapshot());workspace.clearActivePlan();const saved=clone(workspace.snapshot()),active=workspace.activePayload();
  assert.equal(saved.activeId,initial);assert.equal(saved.plans[0].name,before.plans[0].name);
  assert.deepEqual(stable(saved.plans.find(p=>p.id===second)),before.plans.find(p=>p.id===second));
  assert.equal(active.informacionGeneral.nivel,'');assert.equal(active.metodologiaActiva,'');assert.equal(active.pia.context.group,'');assert.equal(active.pia.evaluation.projectPlanning.title,'');assert.equal(active.pia.aiPrompts.semester,'');assert.equal(active.piaWeeklyDraftPrompt,'');assert.equal(active.pia.routeMap.aiExchange.responseText,'');assert.equal(active.piaImportBackups.length,0);
  assert.equal(active.semanas.length,4);assert.ok(active.semanas.every(w=>w.actividades===''&&w.evaluacion===''&&w.indicadores===''));
  assert.deepEqual(stable(saved.recovery[0].item),before.plans[0]);
  for(const key of ['pia.workspace.v1','pia.plan.autosave.v6'])assert.equal((JSON.parse(values.get(key)).piaWorkspace||JSON.parse(values.get(key))).recovery.length,1);
});

test('eliminar selecciona otro plan y recuperar no sobrescribe sus cambios',async()=>{
  const {context,workspace}=await harness();context.confirm=()=>true;
  const first=workspace.snapshot().activeId;workspace.addPlan();const second=workspace.snapshot().activeId;
  workspace.switchPlan(first);workspace.deleteActivePlan();assert.equal(workspace.snapshot().activeId,second);assert.equal(workspace.snapshot().plans.length,1);
  context.semanas[0].actividades='CAMBIOS DEL OTRO GRUPO';workspace.restoreManagedPlan();
  const saved=clone(workspace.snapshot());assert.equal(saved.plans.length,2);assert.equal(saved.recovery.length,0);assert.notEqual(saved.activeId,first);
  assert.equal(workspace.activePayload().semanas[0].actividades,'<p>Texto inicial</p>');assert.equal(saved.plans.find(p=>p.id===second).plan.semanas[0].actividades,'CAMBIOS DEL OTRO GRUPO');
});

test('eliminar el último mantiene una plantilla vacía válida y recupera su contenido',async()=>{
  const {context,workspace}=await harness();context.confirm=()=>true;const first=workspace.snapshot().activeId;
  workspace.deleteActivePlan();const saved=workspace.snapshot();assert.equal(saved.plans.length,1);assert.notEqual(saved.activeId,first);assert.equal(workspace.activePayload().semanas[0].actividades,'');assert.ok(workspace.validStore(saved));
  workspace.restoreManagedPlan();assert.equal(workspace.snapshot().plans.length,2);assert.equal(workspace.activePayload().pia.aiPrompts.semester,'Prompt literal');
});

test('duplicar conserva mapa, contexto y prompts pero no comparte objetos editables',async()=>{
  const {context,workspace}=await harness();const first=workspace.snapshot().activeId;
  const original=workspace.activePayload();original.pia.routeMap={positions:{a:{x:17,y:32}},groups:[],connections:[]};original.piaWeeklyDraftPrompt='CONSULTA LITERAL';context.cargarPlan(original);
  workspace.duplicatePlan();const second=workspace.snapshot().activeId;assert.notEqual(first,second);assert.equal(workspace.activePayload().pia.routeMap.positions.a.x,17);assert.equal(workspace.activePayload().piaWeeklyDraftPrompt,'CONSULTA LITERAL');
  context.semanas[0].actividades='CAMBIO SOLO EN COPIA';workspace.switchPlan(first);assert.equal(workspace.activePayload().semanas[0].actividades,'<p>Texto inicial</p>');workspace.switchPlan(second);assert.equal(workspace.activePayload().semanas[0].actividades,'CAMBIO SOLO EN COPIA');
});

test('JSON individual excluye todos los otros planes y los respaldos de gestión',async()=>{
  const {context,workspace}=await harness();context.confirm=()=>true;workspace.clearActivePlan();workspace.addPlan();
  const individual=clone(workspace.activePayload());assert.equal(individual.schemaVersion,6);assert.equal(individual.piaWorkspace,undefined);assert.equal(individual.recovery,undefined);assert.equal(workspace.snapshot().plans.length,2);assert.equal(workspace.snapshot().recovery.length,1);
  const other=await harness();other.context.cargarPlan(individual);assert.equal(other.workspace.snapshot().plans.length,1);
});

test('respaldos se conservan al reabrir autoguardado y JSON conjunto',async()=>{
  const {context,workspace,values}=await harness();context.confirm=()=>true;workspace.clearActivePlan();
  const reopened=await harness({storage:Object.fromEntries(values)});reopened.context.confirm=()=>true;reopened.workspace.restoreManagedPlan();assert.equal(reopened.workspace.activePayload().semanas[0].actividades,'<p>Texto inicial</p>');
  const imported=await harness();imported.context.confirm=()=>true;imported.context.cargarPlan(clone(context.obtenerDatosPlan()));imported.workspace.restoreManagedPlan();assert.equal(imported.workspace.activePayload().pia.aiPrompts.semester,'Prompt literal');
});

test('respaldos conservan los últimos cinco y rechazan conjuntos malformados',async()=>{
  const {context,workspace}=await harness();context.confirm=()=>true;for(let i=0;i<6;i++){context.semanas[0].actividades=String(i);workspace.clearActivePlan();}
  const saved=clone(workspace.snapshot());assert.equal(saved.recovery.length,5);assert.equal(saved.recovery[0].item.plan.semanas[0].actividades,'1');assert.equal(saved.recovery.at(-1).item.plan.semanas[0].actividades,'5');
  const incoming=clone(context.obtenerDatosPlan());incoming.piaWorkspace.recovery=[{kind:'delete',date:'hoy',item:{}}];assert.throws(()=>context.cargarPlan(incoming),/conjunto/);assert.equal(workspace.snapshot().recovery.length,5);
});

test('sin espacio local no se limpia ni elimina y se informa la falla',async()=>{
  for(const operation of ['clearActivePlan','deleteActivePlan']){
    const {context,workspace,values}=await harness();context.confirm=()=>true;workspace.persist();const before=stable(workspace.snapshot()),stored=Object.fromEntries(values),messages=[];context.mostrarMensaje=text=>messages.push(text);context.localStorage.setItem=()=>{throw Error('quota');};
    workspace[operation]();assert.deepEqual(stable(workspace.snapshot()),before);assert.deepEqual(Object.fromEntries(values),stored);assert.match(messages.at(-1),/sigue intacto/);
  }
});

test('fallar la segunda escritura revierte ambos almacenes y el cambio visible',async()=>{
  const {context,workspace,values}=await harness();context.confirm=()=>true;context.cargarPlan(clone(workspace.activePayload()));workspace.persist();const before=stable(workspace.snapshot()),stored=Object.fromEntries(values),write=context.localStorage.setItem;let calls=0;
  // Checkpoint writes succeed; final autosave fails, and the rollback can write.
  context.localStorage.setItem=(key,value)=>{if(++calls===4)throw Error('quota');write(key,value);};
  workspace.clearActivePlan();assert.deepEqual(stable(workspace.snapshot()),before);assert.equal(workspace.activePayload().semanas[0].actividades,'<p>Texto inicial</p>');
  const persisted=JSON.parse(values.get('pia.workspace.v1'));assert.equal(persisted.plans[0].plan.semanas[0].actividades,'<p>Texto inicial</p>');assert.equal(persisted.recovery.length,1);assert.equal(JSON.parse(values.get('pia.plan.autosave.v6')).piaWorkspace.recovery.length,1);
  assert.notEqual(values.get('pia.workspace.v1'),stored['pia.workspace.v1']);
});

test('máximo de treinta impide duplicar o recuperar sin perder el respaldo',async()=>{
  const {context,workspace}=await harness();context.confirm=()=>true;workspace.clearActivePlan();const incoming=clone(context.obtenerDatosPlan());const first=clone(incoming.piaWorkspace.plans[0]);incoming.piaWorkspace.plans=Array.from({length:30},(_,i)=>({...clone(first),id:'p'+i}));incoming.piaWorkspace.activeId='p0';context.cargarPlan(incoming);
  workspace.duplicatePlan();workspace.restoreManagedPlan();assert.equal(workspace.snapshot().plans.length,30);assert.equal(workspace.snapshot().recovery.length,1);
});
