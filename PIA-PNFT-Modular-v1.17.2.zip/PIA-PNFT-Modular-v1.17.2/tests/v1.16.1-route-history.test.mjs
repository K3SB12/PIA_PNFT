import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
const read=path=>readFile(new URL('../'+path,import.meta.url),'utf8');
const [coreSource,runtime]=await Promise.all([read('src/domain/projection/projection-core.js'),read('src/application/enhancements.js')]);
const context=vm.createContext({encodeURIComponent});vm.runInContext(coreSource+'\nglobalThis.core=PIAProjectionCore;',context);const core=context.core,plain=v=>JSON.parse(JSON.stringify(v));
const old={schemaVersion:5,enhancements:{projection:{conceptIds:['a','b']},methodology:{routeAssignments:{a:{role:'prepare',phaseId:'prototype',weekStart:7,weekEnd:8,groupId:'g',note:'Contexto exacto (anterior)'},b:{role:'integrated',phaseId:'test-evaluate',weekStart:16,weekEnd:17}}},routeMap:{confirmed:true,semanticFingerprint:'pia-route-antigua',groups:[{id:'g',title:'Grupo histórico',note:'Sin cambiar'}],positions:{'concept-a':{x:23,y:-11},'project':{x:5,y:12}},connections:[{id:'ab',from:'a',to:'b',type:'prepares',note:'Vínculo anterior'}],phaseSchedule:[{id:'prototype',weekStart:7,weekEnd:8,note:'Preparar y construir',linkedConceptIds:['a']},{id:'test-evaluate',weekStart:16,weekEnd:17,note:'Cierre',linkedConceptIds:['b']}],aiExchange:{revisionHistory:[{optionId:'p1',title:'Primera',reason:'Ajustada por asesoría',option:{id:'p1',project:{product:'Simulación'}}}]}},aiPrompts:{semester:'Texto editado\n\n(Conservar)',weekly:{1:'Semana editada'}}}};

test('el JSON histórico conserva fases con id, grupos, posiciones, relaciones y textos tras dos cargas',()=>{
 const first=plain(core.migrate(old)),again=plain(core.migrate({pia:JSON.parse(JSON.stringify(first))}));
 assert.deepEqual(again,first);assert.equal(first.routeMap.phaseSchedule.length,2);assert.equal(first.routeMap.phaseSchedule[0].phaseId,'prototype');assert.equal(first.routeMap.phaseSchedule[0].weekEnd,8);assert.equal(first.routeMap.phaseSchedule[0].note,'Preparar y construir');
 assert.deepEqual(first.routeMap.positions,old.enhancements.routeMap.positions);assert.deepEqual(first.routeMap.connections,old.enhancements.routeMap.connections);assert.equal(first.routeMap.confirmed,true);assert.equal(first.routeMap.aiExchange.revisionHistory[0].reason,'Ajustada por asesoría');assert.equal(first.aiPrompts.semester,old.enhancements.aiPrompts.semester);assert.equal(first.methodology.routeAssignments.a.note,'Contexto exacto (anterior)');
});
test('una fase normalizada con phaseId también conserva el rango, nota y referencias',()=>{
 const result=core.migrate({pia:{projection:{conceptIds:['b']},routeMap:{phaseSchedule:[{phaseId:'define',weekStart:4,weekEnd:5,note:'Síntesis',linkedConceptIds:['b']}]}}});assert.equal(result.routeMap.phaseSchedule[0].id,'define');assert.equal(result.routeMap.phaseSchedule[0].weekEnd,5);assert.deepEqual(plain(result.routeMap.phaseSchedule[0].linkedConceptIds),['b']);
});
test('un plan con pia administrativo parcial no oculta el mapa almacenado en enhancements',()=>{
 const result=core.migrate({...old,pia:{context:{group:'Actual'},methodology:{purpose:'Propósito actual'}}});assert.equal(result.context.group,'Actual');assert.equal(result.methodology.purpose,'Propósito actual');assert.equal(result.methodology.routeAssignments.a.weekStart,7);assert.equal(result.routeMap.phaseSchedule.length,2);
});
test('las relaciones entre saberes seleccionados sin asignación permanecen visibles como pendientes',()=>{
 const result=core.migrate({pia:{projection:{conceptIds:['a','b']},routeMap:{connections:[{id:'ab',from:'a',to:'b',type:'prepares'}]}}});assert.equal(result.routeMap.connections.length,1);assert.deepEqual(plain(result.methodology.routeAssignments),{});
});
test('si no había agenda de fases se recupera la declarada en la propuesta guardada; una agenda vaciada se respeta',()=>{
 const source={routeMap:{aiExchange:{selectedOptionSnapshot:{phases:[{id:'prototype',weekStart:10,weekEnd:14}]}}}};assert.equal(core.migrate({pia:source}).routeMap.phaseSchedule[0].weekStart,10);source.routeMap.phaseSchedule=[];assert.equal(core.migrate({pia:source}).routeMap.phaseSchedule.length,0);
});
test('la ordenación y las etiquetas muestran semanas discontinuas y pendientes sin inventar rangos',()=>{
 const start=runtime.indexOf('function routeWeeksLabel'),end=runtime.indexOf('function routeGraphModel(concepts)',start),ctx=vm.createContext({});vm.runInContext(runtime.slice(start,end)+'\nglobalThis.label=routeWeeksLabel;globalThis.summary=routeWeeksSummary;',ctx);
 assert.equal(ctx.label({weekStart:4,weekEnd:4}),'Semana 4');assert.equal(ctx.label({weekStart:0,weekEnd:8}),'Semana inicial pendiente · final 8');assert.equal(ctx.summary([{weekStart:4,weekEnd:5},{weekStart:7,weekEnd:7}]),'Semanas 4–5, 7');assert.equal(ctx.summary([{weekStart:0},{weekStart:4}]),'Semanas 4 · 1 saber(es) sin rango completo');
});
