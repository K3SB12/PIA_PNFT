import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';

const read=path=>readFile(new URL('../'+path,import.meta.url),'utf8');
const clone=value=>JSON.parse(JSON.stringify(value));
async function harness({embedded,storage={}}={}){
  const ids=new Map(),values=new Map(Object.entries(storage)),events={};
  function node(id=''){
    const n={id,value:'',textContent:'',hidden:false,children:[],dataset:{},classList:{remove(){},add(){}},focus(){},matches(){return false;},querySelector(){return null;},querySelectorAll(){return [];},prepend(child){this.children.unshift(child);},after(){},append(){},insertBefore(){},remove(){ids.delete(this.id);},setAttribute(){},replaceChildren(){},click(){}};
    Object.defineProperty(n,'innerHTML',{get(){return this.html||'';},set(html){this.html=html;for(const match of html.matchAll(/id="([^"]+)"/g))if(!ids.has(match[1]))ids.set(match[1],node(match[1]));}});
    return n;
  }
  const root=node();
  for(const id of ['piaProjection','piaReview','metodologiaActiva','metodologiaPersonalizada','metodologiaPersonalizadaContainer','observaciones'])ids.set(id,node(id));
  const document={getElementById:id=>ids.get(id),querySelector:selector=>selector==='.container'?root:selector==='.pia-tools'?node():null,querySelectorAll(){return [];},createElement(){const n=node();Object.defineProperty(n,'id',{get(){return this.key||'';},set(id){this.key=id;ids.set(id,this);}});return n;},addEventListener(type,fn){(events[type]||=[]).push(fn);},body:{append(){}}};
  let current={schemaVersion:6,informacionGeneral:{nivel:'7°',ciclo:'III Ciclo',leccionesPlanificadas:'2'},ejesTransversales:[],metodologiaActiva:'APD',observaciones:'Notas iniciales',semanas:[{id:1,actividades:'<p>Texto inicial</p>'}],pia:{aiPrompts:{semester:'Prompt literal'}}};
  const context=vm.createContext({document,console,Date,Math,JSON,Set,Map,structuredClone,setTimeout(){return 1;},clearTimeout(){},prompt(){return 'Grupo nuevo';},alert(){},mostrarMensaje(){},localStorage:{getItem:key=>values.get(key)||null,setItem(key,value){values.set(key,value);}},PIAProjectComponentCatalog:{defaultWeekProject:()=>({mode:'curricular',stageId:'',phaseId:'',records:{}})},PIAEnhancements:{getState:()=>current.pia,exchangeFingerprint:()=>'same',selectedConcepts:()=>[{id:'saber-1'}]},semanas:clone(current.semanas),obtenerDatosPlan(){return {...clone(current),semanas:clone(context.semanas),metodologiaActiva:ids.get('metodologiaActiva').value,observaciones:ids.get('observaciones').value,fechaGuardado:new Date().toISOString()};},cargarPlan(plan){current={...current,...clone(plan)};if(plan.semanas.length)context.semanas=clone(plan.semanas);if(plan.metodologiaActiva)ids.get('metodologiaActiva').value=plan.metodologiaActiva;if(plan.observaciones)ids.get('observaciones').value=plan.observaciones;},reconstruirVistaSemanasPreservandoContenido(){},nuevoPlan(){}});
  context.window={__PIA_EMBEDDED_PLAN__:embedded,alert(){},addEventListener(){},scrollTo(){}};
  ids.get('metodologiaActiva').value='APD';ids.get('observaciones').value='Notas iniciales';
  const source=(await read('src/application/workspace/workspace.js')).replace('return {snapshot,','return {testInit:init,snapshot,switchPlan,persist,addPlan,prepareWeeks,request,');
  vm.runInContext(await read('src/domain/projection/projection-core.js'),context);
  vm.runInContext(source+'\nglobalThis.workspace=PIAWorkspace;',context);
  context.workspace.testInit();
  return {context,workspace:context.workspace,ids,values};
}

test('nuevo grupo mantiene intacto el anterior y nace sin contenido, prompts ni respaldos',async()=>{
  const {context,workspace}=await harness();
  const original=workspace.snapshot().activeId;
  workspace.addPlan();
  const saved=clone(context.obtenerDatosPlan());
  assert.equal(saved.piaWorkspace.plans.length,2);
  assert.equal(saved.metodologiaActiva,'');
  assert.equal(saved.observaciones,'');
  assert.equal(saved.informacionGeneral.nivel,'');
  assert.equal(saved.pia.aiPrompts.semester,'');
  assert.equal(saved.piaWeeklyDraftPrompt,'');
  assert.equal(saved.semanas.length,4);
  assert.ok(saved.semanas.every(w=>w.actividades===''&&w.saberes.length===0));
  workspace.switchPlan(original);
  assert.equal(context.obtenerDatosPlan().semanas[0].actividades,'<p>Texto inicial</p>');
  assert.equal(context.obtenerDatosPlan().pia.aiPrompts.semester,'Prompt literal');
});

test('cambio de plan conserva literalmente semanas, prompts y observaciones en ambos almacenes',async()=>{
  const {context,workspace,values}=await harness();
  const first=workspace.snapshot().activeId;
  context.semanas[0].actividades='<p><strong>Dato (con formato)</strong></p>';
  workspace.addPlan();
  workspace.switchPlan(first);
  workspace.persist();
  for(const key of ['pia.workspace.v1','pia.plan.autosave.v6']){
    const saved=JSON.parse(values.get(key)),store=key==='pia.workspace.v1'?saved:saved.piaWorkspace;
    assert.equal(store.activeId,first);
    assert.equal(store.plans.find(p=>p.id===first).plan.semanas[0].actividades,'<p><strong>Dato (con formato)</strong></p>');
  }
  const restored=await harness({storage:Object.fromEntries(values)});
  assert.equal(restored.context.obtenerDatosPlan().semanas[0].actividades,'<p><strong>Dato (con formato)</strong></p>');
  assert.equal(restored.context.obtenerDatosPlan().pia.aiPrompts.semester,'Prompt literal');
});

test('abrir JSON conjunto restaura grupos y rechaza conjuntos inválidos sin borrar el estado',async()=>{
  const first=await harness();first.workspace.addPlan();
  const exported=clone(first.context.obtenerDatosPlan());
  const second=await harness();second.context.cargarPlan(exported);
  assert.equal(second.workspace.snapshot().plans.length,2);
  const before=clone(second.workspace.snapshot());
  assert.throws(()=>second.context.cargarPlan({...exported,piaWorkspace:{schema:'pia-workspace-v1',plans:[]}}),/conjunto/);
  const withoutDates=plans=>plans.map(p=>({...p,plan:{...p.plan,fechaGuardado:''}}));
  assert.deepEqual(withoutDates(clone(second.workspace.snapshot()).plans),withoutDates(before.plans));
});

test('cargar un plan vacío no arrastra metodología, observaciones ni semanas del activo',async()=>{
  const {context}=await harness();
  context.cargarPlan({informacionGeneral:{nivel:'8°',ciclo:'III Ciclo'},semanas:[]});
  const saved=context.obtenerDatosPlan();
  assert.equal(saved.metodologiaActiva,'');assert.equal(saved.observaciones,'');assert.equal(saved.semanas.length,0);
});

test('portable prioriza conjunto embebido sobre el local y nuevo grupo no lo duplica',async()=>{
  const original=await harness();original.workspace.addPlan();
  const embedded=clone(original.context.obtenerDatosPlan());
  const local=await harness();local.workspace.persist();
  const fresh=await harness({embedded,storage:Object.fromEntries(local.values)});
  assert.equal(fresh.workspace.snapshot().plans.length,2);
  fresh.workspace.addPlan();
  assert.equal(fresh.workspace.snapshot().plans.length,3);
  assert.equal(fresh.context.obtenerDatosPlan().pia.aiPrompts.semester,'');
});

test('la recuperación usa el autoguardado más reciente aunque el conjunto local quedó atrasado',async()=>{
  const original=await harness();original.workspace.persist();
  const autosave=JSON.parse(original.values.get('pia.plan.autosave.v6'));
  autosave.fechaGuardado='2099-01-01T00:00:00.000Z';autosave.semanas[0].actividades='Respuesta más reciente';
  original.values.set('pia.plan.autosave.v6',JSON.stringify(autosave));
  const restored=await harness({storage:Object.fromEntries(original.values)});
  assert.equal(restored.context.obtenerDatosPlan().semanas[0].actividades,'Respuesta más reciente');
});


test('texto editado de la nueva consulta semanal conserva formato literal en exportación y recuperación',async()=>{
  const {context,workspace,ids,values}=await harness();
  // The query mode is entered only after the existing prerequisite checks.
  const plan=clone(context.obtenerDatosPlan());
  plan.metodologiaActiva='ABJ';plan.informacionGeneral.ciclo='I Ciclo';
  plan.pia={...plan.pia,calendar:{weeks:1},evaluation:{confirmed:true}};
  context.PIAEnhancements.weeklyDraftContext=()=> 'Consulta generada';
  context.cargarPlan(plan);
  workspace.request();
  const literal='Consulta docente\n\n**Inicio (10 min)**\nProponga ideas originales.';
  ids.get('piaExchangeText').value=literal;
  ids.get('piaExchangeText').oninput({target:ids.get('piaExchangeText')});
  ids.get('piaExchangeClose').onclick();workspace.persist();
  const json=clone(context.obtenerDatosPlan());
  assert.equal(json.piaWeeklyDraftPrompt,literal);
  assert.equal(json.piaWorkspace.plans.find(p=>p.id===json.piaWorkspace.activeId).plan.piaWeeklyDraftPrompt,literal);
  const restored=await harness({storage:Object.fromEntries(values)});
  assert.equal(restored.context.obtenerDatosPlan().piaWeeklyDraftPrompt,literal);
  workspace.addPlan();assert.equal(context.obtenerDatosPlan().piaWeeklyDraftPrompt,'');
});

test('preparar estructura agrega faltantes sin cambiar el contenido ni reducir semanas',async()=>{
  const {context,workspace}=await harness();
  const plan=clone(context.obtenerDatosPlan());plan.pia.calendar={weeks:3};context.cargarPlan(plan);
  context.confirm=()=>true;
  context.agregarSemanaManual=()=>context.semanas.push({id:context.semanas.length+1,actividades:''});
  workspace.prepareWeeks();
  assert.equal(context.semanas.length,3);
  assert.equal(context.semanas[0].actividades,'<p>Texto inicial</p>');
  const shorter=clone(context.obtenerDatosPlan());shorter.pia.calendar.weeks=1;context.cargarPlan(shorter);
  workspace.prepareWeeks();assert.equal(context.semanas.length,3);
});

test('borrador fuera del rango confirmado y cobertura parcial se advierten sin certificar RdA',async()=>{
  const {context,workspace}=await harness();
  const plan=clone(context.obtenerDatosPlan());
  plan.pia.methodology={routeAssignments:{'saber-1':{weekStart:2,weekEnd:3}}};context.cargarPlan(plan);
  context.PIAEnhancements.selectedConcepts=()=>[{id:'saber-1',name:'Algoritmos'},{id:'saber-2',name:'Redes'}];
  const result=workspace.normalizeDraft({schema:'pia-weekly-draft-v1',fingerprint:'same',weeks:[{weekNumber:1,conceptIds:['saber-1'],mediationHtml:'',evaluationHtml:'',resourcesHtml:''}]});
  assert.match(result.rows[0].warnings[0],/fuera de su rango 2–3/);
  assert.match(result.warnings[0],/1 saber.*no aparecen/);
  assert.match(result.warnings[0],/no certifica cobertura ni RdA/);
});


test('los JSON anteriores que guardaban enhancements mantienen sus prompts y contexto',async()=>{
  const {context}=await harness();
  context.cargarPlan({informacionGeneral:{nivel:'8°',ciclo:'III Ciclo'},semanas:[{id:1,actividades:'Legado'}],enhancements:{aiPrompts:{semester:'PROMPT LEGADO'},context:{group:'CONTEXTO LEGADO'}}});
  const saved=context.obtenerDatosPlan();
  assert.equal(saved.pia.aiPrompts.semester,'PROMPT LEGADO');
  assert.equal(saved.pia.context.group,'CONTEXTO LEGADO');
});
