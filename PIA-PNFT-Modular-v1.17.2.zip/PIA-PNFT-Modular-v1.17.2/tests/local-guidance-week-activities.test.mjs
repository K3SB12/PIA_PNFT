import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const root = new URL('../', import.meta.url);
const read = path => readFile(new URL(path, root), 'utf8');

test('el asistente local recupera fuente, páginas, confianza y relacionadas sin API', async () => {
  const source = await read('src/data/pia-guidance-knowledge.js');
  assert.doesNotMatch(source, /\bfetch\s*\(|XMLHttpRequest|sendBeacon|WebSocket/);
  const context = vm.createContext({});
  vm.runInContext(`${source}\n;globalThis.guidance=PIALocalGuidance;`, context);
  const result = context.guidance.search('¿Cómo aplicar DUA y representación?');
  assert.equal(result.match.id, 'dua');
  assert.equal(result.confidence, 'alta');
  assert.match(result.match.pages, /8/);
  assert.equal(result.match.sourceDetail.status, 'Fuente oficial localizada');
  assert.ok(result.related.length >= 1);
  const fallback = context.guidance.search('xilófono cuántico interplanetario');
  assert.equal(fallback.match, null);
  const prompt = context.guidance.externalPrompt('Pregunta nueva', 'III Ciclo');
  assert.match(prompt, /No invente currículo/);
  assert.match(prompt, /III Ciclo/);
  for (const [question,id] of [
    ['no aparece proyecto','proyecto-no-aparece'],
    ['requisitos para organizar ruta','requisitos-ruta'],
    ['ajustar propuesta','propuesta-ajustes'],
    ['guardar json y autoguardado','guardado-json'],
    ['mapa y calendario','mapa-calendario'],
    ['generar prompt semanal','generar-prompt'],
  ]) assert.equal(context.guidance.search(question).match.id,id);
});

test('la planificación puntual semanal normaliza, persiste como objeto y no se rotula metodología', async () => {
  const source = await read('src/domain/planning/week-activity-planning.js');
  const context = vm.createContext({});
  vm.runInContext(`${source}\n;globalThis.activity=PIAWeekActivityPlanning;`, context);
  const week = {};
  const value = context.activity.ensure(week);
  value.organization = 'pairs';
  value.activityType = 'short-challenge';
  value.environment = 'disconnected';
  week.activityPlanning = context.activity.normalize(value);
  assert.equal(week.activityPlanning.organization, 'pairs');
  assert.equal(week.activityPlanning.activityType, 'short-challenge');
  assert.equal(week.activityPlanning.environment, 'disconnected');
  const prompt = context.activity.promptBlock(week.activityPlanning);
  assert.match(prompt, /Parejas/);
  assert.match(prompt, /Reto breve/);
  assert.match(prompt, /Actividad desconectada/);
  assert.match(prompt, /no constituyen por sí mismas otra metodología/i);
  const serialized = JSON.parse(JSON.stringify({ semanas:[week] }));
  assert.equal(JSON.stringify(serialized.semanas[0].activityPlanning), JSON.stringify(week.activityPlanning));
});

test('los apoyos declarados generan un contrato diferenciado sin datos personales', async () => {
  const source = await read('src/domain/planning/week-activity-planning.js');
  const context = vm.createContext({});
  vm.runInContext(`${source}\n;globalThis.activity=PIAWeekActivityPlanning;`, context);
  const prompt = context.activity.supportPromptBlock({enabled:true,supportFramework:'significant-approved',duaSupports:['representation'],authorizedSupportNotes:'Usar apoyos visuales autorizados.'});
  assert.match(prompt, /estrategia común/i);
  assert.match(prompt, /previamente aprobada/i);
  assert.match(prompt, /no interprete ni redacte la PEI/i);
  assert.match(prompt, /nombres, diagnósticos clínicos, expedientes ni datos sensibles/i);
  assert.match(prompt, /formas equivalentes de evidenciar/i);
});

test('la isla muestra referencias vocacionales sin incorporarlas y conserva fases ocultas', async () => {
  const source = await read('src/application/utility-assistant.js');
  assert.match(source, /Referencia opcional para Plan Nacional/);
  assert.match(source, /no los incorpora automáticamente/i);
  assert.match(source, /details\.open=true/);
  assert.match(source, /pia-project-hidden-for-curricular/);
  assert.doesNotMatch(source, /phaseId\s*=\s*['"]{2}|delete\s+week\.project/);
  assert.match(source, /activityPlanning/);
  assert.match(source, /Estado de la selección actual/);
  assert.match(source, /result\.confidence==='baja'/);
  assert.match(source, /PIA no transmite la pregunta/);
});

test('los prompts semanal y semestral exigen mediación diferenciada segura', async () => {
  const weekly = await read('src/prompts/weekly-prompt.js');
  const semester = await read('src/prompts/semester-projection-prompt.js');
  assert.match(weekly, /activityPlanningBlock/);
  assert.match(weekly, /differentiatedSupportBlock/);
  assert.match(weekly, /no interprete una PEI ni invente adecuaciones/i);
  assert.match(semester, /Opciones diferenciadas según apoyos declarados/);
  assert.match(semester, /no incluya nombres, diagnósticos clínicos, expedientes ni datos sensibles/i);
});

test('el ensamblado incluye el asistente y los controles en orden seguro', async () => {
  const manifest = await read('scripts/fragment-manifest.mjs');
  const built = await read('index.html');
  assert.match(manifest, /pia-guidance-knowledge\.js/);
  assert.match(manifest, /week-activity-planning\.js/);
  assert.match(manifest, /utility-assistant\.js/);
  assert.match(built, /PIA_LOCAL_GUIDANCE_KNOWLEDGE_START/);
  assert.match(built, /PIA_WEEK_ACTIVITY_PLANNING_START/);
  assert.match(built, /PIA_UTILITY_ASSISTANT_START/);
});

test('la orientación local ocupa la pantalla móvil sin perder acciones ni zonas seguras', async () => {
  const assistantCss = await read('src/styles/10-utility-assistant.css');
  assert.match(assistantCss,/\.pia-guidance-dialog\{width:100vw;max-width:none;height:100dvh;max-height:100dvh/);
  assert.match(assistantCss,/\.pia-guidance-actions\{display:grid;grid-template-columns:1fr\}/);
  assert.match(assistantCss,/env\(safe-area-inset-bottom\)/);
});
