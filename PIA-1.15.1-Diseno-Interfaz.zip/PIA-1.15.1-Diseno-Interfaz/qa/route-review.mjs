import {chromium} from '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
const root=process.cwd();
const browser=await chromium.launch({executablePath:'/tmp/pia-chromium',args:['--no-sandbox','--disable-gpu','--disable-dev-shm-usage','--no-zygote','--single-process','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'],headless:true});
const page=await browser.newPage({viewport:{width:1440,height:1000}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.goto('file://'+(process.env.PIA_APP_ROOT||root)+'/index.html');await page.locator('#piaStartPlanning').click();
await page.locator('#ciclo').selectOption('III Ciclo');await page.locator('#nivel').selectOption('8°');await page.locator('#metodologiaActiva').selectOption('APD');
await page.locator('label.pia-choice-card').filter({has:page.locator('input[name="piaModule"][value="Módulo 1"]')}).click();
await page.locator('label.pia-area-card').nth(0).click();await page.locator('label.pia-area-card').nth(1).click();
await page.locator('#piaEvaluationProfile').selectOption('secondary');await page.locator('#piaEvaluationProfileConfirmed').check();
await page.locator('#piaOpenRoutePlanner').click();await page.waitForTimeout(150);
async function assertDestination(step) {
 const targets={proposal:'piaRouteAISection',map:'piaRouteMap',weeks:'piaRouteTimelineSection',review:'piaRouteAssignmentsSection'};
 const result=await page.evaluate(id=>{const target=document.getElementById(id),panel=document.querySelector('#piaRoutePlannerModal .pia-modal-panel');return{target:target.getBoundingClientRect().top,panel:panel.getBoundingClientRect().top,scroll:panel.scrollTop,total:panel.scrollHeight,client:panel.clientHeight};},targets[step]);
 assert.ok(result.target>=result.panel-2 && result.target<result.panel+result.client-100,`Destination ${step} not reached: ${JSON.stringify(result)}`);console.log('DESTINATION',step,'PASS',result);
}

assert.equal(await page.locator('[data-pia-route-step]').count(),7);
for(const id of ['piaRouteAnalyze','piaRouteImportJsonButton','piaRouteProcessAIResponse'])assert.equal(await page.locator('#'+id).count(),1);
await page.locator('[data-pia-route-step="proposal"]').click();await page.waitForTimeout(700);await assertDestination('proposal');await page.screenshot({path:root+'/qa/07-constructor-propuestas.png'});
const before=await page.evaluate(()=>obtenerDatosPlan());
for(const step of ['map','weeks','review']){await page.locator(`[data-pia-route-step="${step}"]`).click();await page.waitForTimeout(700);await assertDestination(step);}
const after=await page.evaluate(()=>obtenerDatosPlan());assert.deepEqual(after.semanas,before.semanas);
assert.deepEqual(after.pia.projection,before.pia.projection);
await page.setViewportSize({width:390,height:844});
for(const step of ['proposal','map','weeks','review']){await page.locator(`[data-pia-route-step="${step}"]`).click();await page.waitForTimeout(700);await assertDestination(step);await page.screenshot({path:root+`/qa/08-movil-constructor-${step}.png`});}
console.log('SCROLL_CONTAINERS',await page.evaluate(()=>Array.from(document.querySelectorAll('#piaRoutePlannerModal,#piaRoutePlannerModal .pia-modal-panel,.container,html,body')).map(n=>({cls:n.className,scroll:n.scrollTop,height:n.clientHeight,total:n.scrollHeight,overflow:getComputedStyle(n).overflowY}))));console.log('ROUTE_TARGETS',await page.evaluate(()=>['piaRouteAISection','piaRouteMap','piaRouteTimelineSection','piaRouteAssignmentsSection'].map(id=>{const n=document.getElementById(id);return{id,display:getComputedStyle(n).display,hidden:n.hidden,top:n.getBoundingClientRect().top,height:n.getBoundingClientRect().height,scroll:document.getElementById('piaRoutePlannerModal').scrollTop};})));await page.locator('#piaRoutePlannerClose').click();
for(const fn of ['exportarAWord','exportarAPDF']){
 const popupPromise=page.waitForEvent('popup');await page.evaluate(name=>window[name](),fn);const popup=await popupPromise;await popup.waitForLoadState('domcontentloaded');assert.equal(await popup.locator('#piaWorkspaceNavigation').count(),0);console.log(fn,'POPUP_NO_NAV=PASS',await popup.title());await popup.close();
}
assert.deepEqual(errors,[]);console.log('CONSTRUCTOR_STRUCTURE_STATE_EXPORT=PASS 7controles 3acciones clicssinpérdida mobile390 WordPDFsinmenú; INTERNAL_SCROLL=FIXED_AND_VERIFIED');
await fs.writeFile(root+'/qa/route-review-results.json',JSON.stringify({structuralStateAndExportPass:true,internalScroll:'Fixed; desktop and mobile destinations reached',errors,steps:7,actions:3,mobileWidth:390},null,2));await browser.close();
