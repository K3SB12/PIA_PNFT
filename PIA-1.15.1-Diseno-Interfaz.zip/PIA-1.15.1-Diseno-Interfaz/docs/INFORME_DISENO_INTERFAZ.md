# PIA 1.15.1 — Mejora del diseño de interfaz

Fecha: 1 de octubre de 2026. Edición visual sobre la base curricular 1.15.1; JSON v6.

## Entrega

Abra index.html en Chrome o Edge. El archivo es autónomo. El ZIP contiene fuentes, salidas web y portable, contratos, pruebas y evidencia de revisión. No se publicó ni se sustituyó la página GitHub Pages.

## Cambios

- Menú lateral de seis accesos en escritorio y tarjetas de navegación en flujo en tableta y celular.
- Identificación del ciclo y nivel actuales, sección activa, Anterior y Continuar; navegación con teclado y foco visible.
- Conservación del orden vigente: encabezado, ejes, metodología, contexto, proyección, seguridad y semanas. Los accesos son destinos del formulario existente; no seis páginas nuevas.
- Jerarquía visual, separación de bloques, espaciado y legibilidad. Portada, textos, controles y estilos de botones existentes conservados.
- Adaptación de encabezado administrativo, ejes, contexto, cabecera de proyección y columnas de la semana. Las tres columnas originales permanecen en escritorio y se apilan en celular.
- El constructor de III Ciclo conserva navegación, propuestas, mapa, matriz, calendario y edición originales.
- Menú excluido de impresión e inicialización idempotente para el HTML portable.

## Comprobación de conservación

Fuentes cambiadas: src/styles/10-utility-assistant.css, src/application/utility-assistant.js. Todo el resto de src conserva sus bytes originales: catálogos, indicadores, RdA, plantillas, funciones curriculares, prompts, guardado, recuperación y exportadores. Las dos fuentes cambiadas solo contienen inserciones adicionales; no eliminan su contenido anterior. El manifiesto de ejecución y BASELINE.sha256 no se modifican.

La copia original continúa separada en la carpeta de auditoría. CURRENT.sha256 e info/informe de esta entrega reflejan el HTML generado de la edición visual. SPEC documenta el alcance aditivo. No se asigna una versión curricular nueva.

SHA-256 del HTML: `5c745cb7da5117404a5ad435596172d9f88eeb0eb6e3b713c3a4dd1c5a4b0bd8`.

## Pruebas

- npm test: 273 pruebas aprobadas, cero fallos; verificación de fuente, alcance autorizado e integridad de entrega aprobadas.
- Chromium real local: escenario docente 8.º, Módulo 1 y APD. Preparación del plan, acceso a contexto y proyección, edición de semana 4 y navegación de retorno. Sin errores JavaScript.
- Guardado: descarga real de JSON, recuperación por el selector local y conservación del texto de mediación de semana 4 y del contexto. La carga aplica la normalización existente de diagnosisLessons=0 en semanas iniciales; no pierde contenido.
- Navegación por teclado: Enter activa el enlace y actualiza aria-current.
- Pantallas: escritorio 1440×1000, tableta 820×1180 y celular 390×844. En el recorrido probado, document.scrollWidth=390 y viewport=390.
- Constructor: perfil de evaluación de secundaria confirmado, dos áreas seleccionadas; siete destinos y tres acciones IA presentes. Se comprobó en la base un fallo del desplazamiento interno y se añadió una corrección de presentación para desplazar solo el panel del diálogo. Navegación de propuesta, mapa, semanas y revisión conserva exactamente las semanas y la selección de proyección, también en móvil.
- Exportación: Word y PDF abren las vistas generadas con el título esperado y sin el menú. El menú se oculta también en media print.
- Integridad: comparación independiente del segundo apoyo confirma que ninguna fuente fuera de las dos inserciones visuales cambió.

## Alcance de la validación

Es una prueba técnica de tareas docentes, no un estudio con docentes participantes. No se probó el diálogo nativo de impresión en Edge ni se abrió el Word descargado en Microsoft Word. El mapa y calendario conservan su lienzo y desplazamiento interno originales; no se sustituyeron por representaciones nuevas. Los errores curriculares o de intercambio de datos previamente observados en la base quedan fuera de esta edición. Se corrige el desplazamiento visual de los accesos internos del constructor, que también fallaba en la base durante la prueba Chromium. No hay integración nueva con IA, importación automática a semanas, backend ni API.

## Evidencia

Capturas reales y registros en qa/. Los JSON de esa carpeta contienen solo datos ficticios de prueba. Los scripts browser-review.mjs y route-review.mjs son evidencia del entorno de validación y requieren Playwright y Chromium de prueba; no se ejecutan para usar PIA.
