# Informe de validación — PIA 1.15.1

## Incidencia corregida

Los botones **Continuar un planeamiento** de la portada y **Abrir** de la barra principal llamaban al selector de archivos después de un temporizador. Los navegadores pueden bloquear esa apertura porque deja de formar parte del gesto original de la persona usuaria.

## Solución

- Selector JSON persistente y accesible dentro del documento.
- Activación sincrónica desde ambos botones.
- La portada no se oculta al abrir el selector ni al cancelar.
- La transición ocurre solamente después de leer, validar, migrar y cargar el JSON.
- Los archivos inválidos no sustituyen el plan vigente.

## Resultado certificado

La huella SHA-256 definitiva de las tres salidas HTML es:

`5c745cb7da5117404a5ad435596172d9f88eeb0eb6e3b713c3a4dd1c5a4b0bd8`

La auditoría inventarió **115 botones** en las plantillas y comprobó que cada uno conserva una acción identificable por `id`, `onclick` o delegación. La validación automatizada final aprobó **273/273 pruebas**, incluidas las regresiones de apertura, cancelación y carga del planeamiento.
