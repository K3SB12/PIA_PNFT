        // PIA_UTILITY_ASSISTANT_START
        (() => {
            const $=id=>document.getElementById(id);
            const escape=value=>String(value||'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
            const optionHtml=(items,value)=>`<option value="">Sin definir</option>${Object.entries(items).map(([id,label])=>`<option value="${id}" ${id===value?'selected':''}>${escape(label)}</option>`).join('')}`;
            function contextLabel(){const cycle=$('ciclo')?.value||'no indicado',level=$('nivel')?.value||'no indicado',profile=$('piaImplementationProfile')?.selectedOptions?.[0]?.textContent||'no indicado';return `Ciclo: ${cycle}; nivel: ${level}; modalidad: ${profile}`;}
            function injectAssistant(){if($('piaGuidanceButton'))return;document.body.insertAdjacentHTML('beforeend',`<button type="button" id="piaGuidanceButton" class="pia-guidance-button" aria-label="Orientación sobre PIA y el PNFT">? Orientación</button><dialog id="piaGuidanceDialog" class="pia-guidance-dialog" aria-labelledby="piaGuidanceTitle"><div class="pia-guidance-shell"><header class="pia-guidance-header"><div><h2 id="piaGuidanceTitle">Orientación PIA y PNFT</h2><p>Consulta local basada en fuentes curadas. No usa API ni envía información.</p></div><button type="button" class="pia-guidance-close" id="piaGuidanceClose" aria-label="Cerrar">×</button></header><div class="pia-guidance-body"><form class="pia-guidance-search" id="piaGuidanceForm"><label class="sr-only" for="piaGuidanceQuery">Escriba su pregunta</label><input class="input-field" id="piaGuidanceQuery" type="search" maxlength="300" placeholder="Ej.: ¿Un reto breve es ABR?" required><button type="submit" class="btn btn-primary">Buscar orientación</button></form><div id="piaGuidanceResult" class="pia-guidance-result" aria-live="polite"><p>Puede consultar sobre DUA, apoyos, Plan Nacional, referencias, Proyecto, evaluación o actividades desconectadas.</p></div></div><footer class="pia-guidance-footer"><small>La coincidencia de búsqueda no certifica una decisión curricular. Revise siempre la fuente y ejerza criterio profesional.</small></footer></div></dialog>`);}
            function projectReadiness(){const profileConfirmed=Boolean($('piaEvaluationProfileConfirmed')?.checked),profile=typeof PIAEvaluationProfiles!=='undefined'?PIAEvaluationProfiles.get($('piaEvaluationProfile')?.value):null,profileIncludesProject=Boolean(profile&&(profile.components||[]).some(item=>String(Array.isArray(item)?item[0]:item?.name||item?.component||'').toLocaleLowerCase('es').includes('proyecto'))),projectEnabled=Boolean($('piaProjectEnabled')?.checked),conceptCount=document.querySelectorAll('input[name="piaConcept"]:checked').length;const checks=[{ok:profileConfirmed,text:'Perfil de evaluación confirmado por la persona docente'},{ok:profileIncludesProject,text:'El perfil seleccionado contempla Proyecto'},{ok:projectEnabled,text:'Componente Proyecto activado por el perfil confirmado'},{ok:conceptCount>0,text:`Saberes seleccionados para la ruta${conceptCount?` (${conceptCount})`:''}`}];return `<div class="pia-guidance-readiness"><strong>Estado de la selección actual</strong><ul>${checks.map(item=>`<li class="${item.ok?'is-ready':'is-pending'}">${item.ok?'✓':'•'} ${escape(item.text)}</li>`).join('')}</ul>${checks.every(item=>item.ok)?'<p>La entrada mínima está disponible. Puede abrir <strong>Organizar ruta y ver mapa</strong>.</p>':'<p>Complete los puntos pendientes. PIA no los confirmará ni inventará automáticamente.</p>'}</div>`;}
            function relatedHtml(items,label='Preguntas relacionadas:'){return items?.length?`<div class="pia-guidance-related"><strong>${escape(label)}</strong>${items.map(related=>`<button type="button" data-pia-guidance-question="${escape(related.title)}">${escape(related.title)}</button>`).join('')}</div>`:'';}
            function fallbackHtml(query,related=[]){const prompt=PIALocalGuidance.externalPrompt(query,contextLabel());return `${relatedHtml(related,'Coincidencias para revisar:')}<section class="pia-guidance-fallback"><h3>No encontré una coincidencia suficientemente segura</h3><p>PIA no presentará una coincidencia baja como respuesta cierta. Puede revisar las preguntas relacionadas o preparar una consulta externa.</p><textarea id="piaGuidanceExternalPrompt" class="pia-guidance-prompt" readonly>${escape(prompt)}</textarea><div class="pia-guidance-actions"><button type="button" class="btn btn-primary" id="piaGuidanceCopy">Copiar consulta</button><button type="button" class="btn btn-outline" data-pia-guidance-open="https://chatgpt.com/">Abrir ChatGPT</button><button type="button" class="btn btn-outline" data-pia-guidance-open="https://copilot.microsoft.com/">Abrir Copilot</button></div><small>Los botones abren solamente el sitio. PIA no transmite la pregunta ni los datos del plan.</small></section>`;}
            function renderResult(query){const result=PIALocalGuidance.search(query,contextLabel()),target=$('piaGuidanceResult');if(!result.match||result.confidence==='baja'){target.innerHTML=fallbackHtml(query,result.related);return;}const item=result.match,isProjectHelp=['proyecto-no-aparece','requisitos-ruta'].includes(item.id);target.innerHTML=`<article class="pia-guidance-answer"><span class="pia-confidence">Coincidencia ${escape(result.confidence)}</span><h3>${escape(item.title)}</h3><p>${escape(item.answer)}</p>${isProjectHelp?projectReadiness():''}<div class="pia-guidance-source"><strong>${escape(item.sourceDetail.title)}</strong><span>Página(s): ${escape(item.pages)}</span><span>Estado: ${escape(item.sourceDetail.status)}</span></div></article>${relatedHtml(result.related)}`;}
            async function copyText(text){try{await navigator.clipboard.writeText(text);if(typeof mostrarMensaje==='function')mostrarMensaje('✅ Consulta copiada');}catch{const area=document.createElement('textarea');area.value=text;document.body.appendChild(area);area.select();document.execCommand('copy');area.remove();}}
            function ensureActivityUI(item,index){if(item.querySelector('[data-pia-week-activity-planning]'))return;const week=semanas?.[index];if(!week)return;const value=PIAWeekActivityPlanning.ensure(week),project=item.querySelector('[data-pia-week-project]');if(!project)return;project.insertAdjacentHTML('afterend',`<details class="pia-week-activity-planning pia-screen-only" data-pia-week-activity-planning="${index+1}"><summary>Organización y actividad puntual <span class="pia-optional">Opcional</span></summary><div class="pia-week-activity-body"><p class="pia-week-activity-intro">Estas opciones describen cómo se organiza la experiencia; no reemplazan ni crean una metodología.</p><div class="pia-week-activity-grid"><label>Organización<select data-pia-activity-field="organization">${optionHtml(PIAWeekActivityPlanning.OPTIONS.organization,value.organization)}</select></label><label>Tipo de actividad<select data-pia-activity-field="activityType">${optionHtml(PIAWeekActivityPlanning.OPTIONS.activityType,value.activityType)}</select></label><label>Entorno o recurso<select data-pia-activity-field="environment">${optionHtml(PIAWeekActivityPlanning.OPTIONS.environment,value.environment)}</select></label><label class="pia-week-activity-note">Observación docente opcional<input type="text" maxlength="500" data-pia-activity-field="note" value="${escape(value.note)}" placeholder="Condición o intención que la IA debe respetar"></label></div></div></details>`);syncProjectPhaseVisibility(item,index);}
            function syncProjectPhaseVisibility(item,index){const week=semanas?.[index];if(!week)return;const modeSelect=item.querySelector(`[data-pia-project-mode="${index+1}"]`),curricular=(modeSelect?.value||week.project?.mode||'curricular')==='curricular';item.querySelectorAll('[data-pia-project-stage-wrap],[data-pia-project-phase-wrap]').forEach(control=>control.classList.toggle('pia-project-hidden-for-curricular',curricular));let note=item.querySelector('.pia-curricular-phase-note');if(curricular&&!note){note=document.createElement('p');note.className='pia-curricular-phase-note';note.textContent='Esta semana desarrolla lecciones pedagógicas; las fases del Proyecto permanecen guardadas y se muestran al elegir Mixta o Integrada.';modeSelect?.closest('.pia-week-project-grid')?.after(note);}if(note)note.hidden=!curricular;}
            function enhanceWeeks(){document.querySelectorAll('#semanasContainer .semana-item').forEach((item,index)=>ensureActivityUI(item,index));}
            function highlightVocationalReferences(){const vocational=$('piaImplementationProfile')?.value==='vocational',details=$('piaCurricularReference');if(!details)return;details.classList.toggle('pia-vocational-reference-highlight',vocational);let notice=$('piaVocationalReferenceNotice');if(vocational){details.open=true;if(!notice){notice=document.createElement('div');notice.id='piaVocationalReferenceNotice';notice.className='pia-vocational-reference-notice';notice.innerHTML='<strong>Referencia opcional para Plan Nacional</strong><span>Explore indicadores autorizados de otros niveles cuando el diagnóstico y la coordinación pedagógica lo justifiquen.</span><small>PIA no los incorpora automáticamente ni sustituye el currículo vigente.</small>';details.querySelector('.pia-reference-body')?.prepend(notice);}}else notice?.remove();}
            function attach(){
                $('piaGuidanceButton')?.addEventListener('click',()=>{$('piaGuidanceDialog')?.showModal();setTimeout(()=>$('piaGuidanceQuery')?.focus(),0);});$('piaGuidanceClose')?.addEventListener('click',()=>$('piaGuidanceDialog')?.close());$('piaGuidanceDialog')?.addEventListener('click',event=>{if(event.target===$('piaGuidanceDialog'))$('piaGuidanceDialog').close();});$('piaGuidanceForm')?.addEventListener('submit',event=>{event.preventDefault();renderResult($('piaGuidanceQuery').value);});$('piaGuidanceResult')?.addEventListener('click',event=>{const question=event.target.closest('[data-pia-guidance-question]');if(question){$('piaGuidanceQuery').value=question.dataset.piaGuidanceQuestion;renderResult(question.dataset.piaGuidanceQuestion);}if(event.target.id==='piaGuidanceCopy')copyText($('piaGuidanceExternalPrompt')?.value||'');const open=event.target.closest('[data-pia-guidance-open]');if(open)window.open(open.dataset.piaGuidanceOpen,'_blank','noopener,noreferrer');});
                $('piaImplementationProfile')?.addEventListener('change',()=>setTimeout(highlightVocationalReferences,0));
                document.addEventListener('change',event=>{const field=event.target.closest('[data-pia-activity-field]');if(field){const item=field.closest('.semana-item'),index=Number(item?.id?.replace('semana-',''))-1,week=semanas?.[index];if(week){const planning=PIAWeekActivityPlanning.ensure(week);planning[field.dataset.piaActivityField]=field.value;week.activityPlanning=PIAWeekActivityPlanning.normalize(planning);}}if(event.target.matches('[data-pia-project-mode]')){const item=event.target.closest('.semana-item'),index=Number(item?.id?.replace('semana-',''))-1;setTimeout(()=>syncProjectPhaseVisibility(item,index),0);}});
                const container=$('semanasContainer');if(container&&typeof MutationObserver==='function')new MutationObserver(()=>setTimeout(enhanceWeeks,0)).observe(container,{childList:true});
            }
            function init(){injectAssistant();attach();enhanceWeeks();highlightVocationalReferences();}
            document.addEventListener('DOMContentLoaded',init);
            window.PIAUtilityAssistant=Object.freeze({renderWeeks:enhanceWeeks,highlightVocationalReferences});
        })();
        // PIA_WORKSPACE_NAVIGATION_START — presentación; no modifica el plan.
        (() => {
            function initWorkspace() {
                const container = document.querySelector('.container');
                if (!container) return;
                document.body.classList.add('pia-workspace-enabled');
                const sections = [
                    ['piaWorkspaceData', container.querySelector('table'), 'Datos y metodología', 'Encabezado, ejes y metodología'],
                    ['piaWorkspaceContext', document.querySelector('.pia-planning-context'), 'Contexto y apoyos', 'DUA y referencias curriculares'],
                    ['piaProjection', document.getElementById('piaProjection'), 'Proyección semestral', 'Currículo, tiempo y organización'],
                    ['piaHerramientas', document.getElementById('piaHerramientas'), 'Seguridad y recuperación', 'Respaldo y herramientas locales'],
                    ['piaWeekNavigator', document.getElementById('piaWeekNavigator'), 'Planificación semanal', 'Seleccione y desarrolle su semana'],
                    ['piaWorkspaceExport', document.querySelector('.action-buttons'), 'Revisión y exportación', 'Guardar, revisar y compartir']
                ].filter(item => item[1]);
                sections.forEach(([id, element]) => {
                    if (!element.id) element.id = id;
                    element.classList.add('pia-workspace-section');
                });
                document.getElementById('semanasContainer')?.classList.add('pia-workspace-section');
                let nav = document.getElementById('piaWorkspaceNavigation');
                if (!nav) {
                    nav = document.createElement('nav');
                    nav.id = 'piaWorkspaceNavigation';
                    nav.className = 'pia-workspace-navigation pia-screen-only';
                    nav.setAttribute('aria-label', 'Recorrido del planeamiento');
                    nav.innerHTML = `<div class="pia-workspace-brand"><span class="pia-eyebrow">PIA · PNFT</span><h2>Mi planeamiento</h2></div><p class="pia-workspace-context" id="piaWorkspaceContextLabel"></p><ol class="pia-workspace-steps">${sections.map(([id,,title,note], index) => `<li><a class="pia-workspace-step" href="#${id}"><span class="pia-workspace-number" aria-hidden="true">${index + 1}</span><span class="pia-workspace-copy"><strong>${title}</strong><small>${note}</small></span></a></li>`).join('')}</ol><p>Puede avanzar en orden o volver a cualquier sección. La navegación conserva su trabajo.</p><div class="pia-workspace-footer"><a id="piaWorkspacePrevious" href="#${sections[0][0]}">← Anterior</a><a id="piaWorkspaceNext" href="#${sections[1]?.[0] || sections[0][0]}">Continuar →</a></div>`;
                    container.querySelector('.header')?.insertAdjacentElement('afterend', nav);
                }
                function selectSection(index) {
                    nav.querySelectorAll('.pia-workspace-step').forEach((link, position) => {
                        if (position === index) link.setAttribute('aria-current', 'step');
                        else link.removeAttribute('aria-current');
                    });
                    sections.forEach(([, element], position) => element.classList.toggle('pia-workspace-current', position === index));
                    const previous = document.getElementById('piaWorkspacePrevious');
                    const next = document.getElementById('piaWorkspaceNext');
                    previous.href = `#${sections[Math.max(0, index - 1)][0]}`;
                    next.href = `#${sections[Math.min(sections.length - 1, index + 1)][0]}`;
                    previous.hidden = index === 0;
                    next.hidden = index === sections.length - 1;
                }
                nav.addEventListener('click', event => {
                    const link = event.target.closest('a[href^="#"]');
                    if (!link) return;
                    const index = sections.findIndex(item => `#${item[0]}` === link.getAttribute('href'));
                    if (index < 0) return;
                    event.preventDefault();
                    const target = sections[index][1];
                    for (let parent = target; parent && parent !== container; parent = parent.parentElement) {
                        if (parent.tagName === 'DETAILS') parent.open = true;
                    }
                    selectSection(index);
                    target.setAttribute('tabindex', '-1');
                    target.focus({preventScroll: true});
                    target.scrollIntoView({block: 'start', behavior: 'auto'});
                });
                function contextLabel() {
                    const level = document.getElementById('nivel')?.value;
                    const cycle = document.getElementById('ciclo')?.value;
                    document.getElementById('piaWorkspaceContextLabel').textContent = [cycle, level].filter(Boolean).join(' · ') || 'Comience con los datos de su planeamiento.';
                }
                document.addEventListener('change', contextLabel);
                document.addEventListener('pia:plan-loaded', contextLabel);
                // Desplazamiento local del diálogo: evita desplazar la página detrás.
                const routeDialog = document.getElementById('piaRoutePlannerModal');
                routeDialog?.addEventListener('click', event => {
                    const step = event.target.closest('[data-pia-route-step]');
                    if (!step) return;
                    const destinations = {context:'piaRouteExplanation',proposal:'piaRouteAISection',compare:'piaRouteProposalSummary',organize:'piaRouteInspector',map:'piaRouteMap',weeks:'piaRouteTimelineSection',review:'piaRouteAssignmentsSection'};
                    const destination = document.getElementById(destinations[step.dataset.piaRouteStep]);
                    const panel = routeDialog.querySelector('.pia-modal-panel');
                    if (!destination || !panel || !destination.getClientRects().length) return;
                    event.preventDefault();
                    event.stopPropagation();
                    panel.scrollTop += destination.getBoundingClientRect().top - panel.getBoundingClientRect().top - 16;
                    destination.setAttribute('tabindex', '-1');
                    destination.focus({preventScroll:true});
                }, true);
                contextLabel();
                selectSection(0);
                let pendingScroll = false;
                window.addEventListener('scroll', () => {
                    if (pendingScroll) return;
                    pendingScroll = true;
                    requestAnimationFrame(() => {
                        pendingScroll = false;
                        let index = 0;
                        sections.forEach(([, element], position) => {
                            if (element.getBoundingClientRect().top <= 160) index = position;
                        });
                        selectSection(index);
                    });
                }, {passive: true});
                window.PIAWorkspaceNavigation = Object.freeze({refreshContext: contextLabel});
            }
            document.addEventListener('DOMContentLoaded', initWorkspace);
        })();
        // PIA_WORKSPACE_NAVIGATION_END
        // PIA_UTILITY_ASSISTANT_END
