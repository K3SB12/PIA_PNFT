import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const html=readFileSync(new URL('../src/templates/enhancements.html',import.meta.url),'utf8');
const js=readFileSync(new URL('../src/application/enhancements.js',import.meta.url),'utf8');
const css=readFileSync(new URL('../src/styles/08-enhancements.css',import.meta.url),'utf8');

test('el flujo principal ordena diagnóstico, perfil, Proyecto y organizador',()=>{
  const ids=['piaDiagnosisEntryTitle','piaEvaluationTitle','piaProjectTitle','piaCurricularRoutePlannerTitle'];
  const positions=ids.map(id=>html.indexOf(`id="${id}"`));
  assert.ok(positions.every(position=>position>=0));
  assert.deepEqual([...positions].sort((a,b)=>a-b),positions);
  assert.match(html,/id="piaProjectEnabled"[^>]*hidden[^>]*aria-hidden="true"/);
  assert.match(html,/id="piaProjectDetails" class="pia-project-details" hidden/);
});

test('el organizador expone siete destinos únicos y tres acciones IA',()=>{
  const steps=[...html.matchAll(/data-pia-route-step="([^"]+)"/g)].map(match=>match[1]);
  assert.deepEqual(steps,['context','proposal','compare','organize','map','weeks','review']);
  assert.equal(new Set(steps).size,7);
  assert.match(html,/Preparar y copiar consulta/);
  assert.match(html,/Importar respuesta/);
  assert.match(html,/Validar y mostrar propuestas/);
  assert.match(html,/<summary>Más opciones<\/summary>/);
});

test('la precondición de III Ciclo enfoca la confirmación y activa Proyecto',()=>{
  assert.match(js,/function activateProjectForConfirmedProfile\(profile\)/);
  assert.match(js,/state\.evaluation\.confirmed&&profileHasProject\(profile\)/);
  assert.match(js,/piaEvaluationProfileConfirmed'\)\?\.focus\(\)/);
  assert.match(js,/project\.enabled=Boolean\(state\.evaluation\.confirmed&&profileHasProject\(profile\)\)/);
});

test('el contrato aditivo conserva producto, recursos y evidencia',()=>{
  assert.match(js,/project:\{product:cleanProposalText/);
  assert.match(js,/resources:Array\.isArray\(source\?\.project\?\.resources\)/);
  assert.match(js,/id:'project-product',kind:'product'/);
  assert.match(js,/projectProposal:clone\(ensureRouteAIExchange\(\)\.selectedOptionSnapshot\?\.project/);
});

test('cambiar de propuesta exige confirmación y conserva la anterior en el historial',()=>{
  assert.match(js,/const previous=exchange\.selectedOptionSnapshot,changing=previous&&exchange\.selectedOptionId!==option\.id/);
  assert.match(js,/La propuesta anterior permanecerá en el historial/);
  assert.match(js,/if\(!confirm\(message\)\)return notify\('Se conservó la propuesta y la ruta actuales\.'/);
  assert.match(js,/reason:'Sustituida por otra propuesta; conservada para comparación'/);
  assert.match(js,/reason:'Aplicada como borrador'/);
});

test('las propuestas usan acordeón único y el check oscuro no aparenta selección',()=>{
  assert.match(js,/data-pia-route-proposal-card/);
  assert.match(js,/if\(other!==card\)other\.open=false/);
  assert.match(css,/\.pia-route-proposal-summary\{grid-template-columns:minmax\(0,1fr\)\}/);
  assert.match(css,/body\.pia-dark \.pia-choice-check\{[^}]*color:transparent!important/);
  assert.match(css,/input:checked\) \.pia-choice-check\{[^}]*color:#fff!important/);
});

test('el título de saberes identifica el módulo seleccionado',()=>{
  assert.match(html,/id="piaKnowledgeTitleText"/);
  assert.match(js,/Saberes del \$\{modules\[0\]\}/);
  assert.match(js,/Saberes de los módulos 1 y 2/);
});

test('el constructor conserva una superficie táctil completa en tableta y celular',()=>{
  assert.match(css,/\.pia-route-modal>\.pia-modal-panel\{width:100vw;max-width:none;height:100dvh;max-height:100dvh/);
  assert.match(css,/\.pia-route-canvas-shell[^}]*overflow:auto[^}]*-webkit-overflow-scrolling:touch/);
  assert.match(css,/@media\(max-width:520px\)[\s\S]*\.pia-route-steps\{grid-template-columns:1fr\}/);
  assert.match(css,/env\(safe-area-inset-bottom\)/);
});
