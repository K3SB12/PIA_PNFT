# Informe de validación — PIA 1.17.3

2 de octubre de 2026.

## Cambios autorizados

La captura muestra etiquetas de dos líneas fuera del borde de botones de 36 px. Los botones de gestión y Nuevo planeamiento usan altura automática, mínimo 44 px, ancho limitado y salto de línea. No se cambian acciones ni confirmaciones.

El RdA de Ciencia de datos de II Ciclo se corrige literalmente con el texto aportado desde quinto; el catálogo es compartido por cuarto, quinto y sexto. El indicador de Sistema operativo se corrige exclusivamente en sexto, Módulo 1, Apropiación tecnológica y Digital. El indicador de quinto permanece igual. No se reemplazan contenidos guardados por docentes.

## Verificación

Suite npm test: 329 pruebas aprobadas; fuente, alcance autorizado, ensamblado, integridad y regresión. Tres nuevas comprobaciones verifican el alcance exacto contra huellas de la entrega 1.17.2, la resolución del RdA y los indicadores de quinto/sexto. Evidencia: evidence/npm-test-1.17.3.log.

Las referencias históricas, BASELINE.sha256 y orden de fragmentos permanecen intactos. Validación visual en Safari/iOS y escritorio: pendiente; las pruebas automatizadas no certifican esos navegadores ni impresión/descargas nativas.

SHA-256 de las tres salidas HTML: `d461c8bfaec28bfae9b7d90c61c60b00a3a4aa607c5ed6f5e120c23680a9dc8a`.
