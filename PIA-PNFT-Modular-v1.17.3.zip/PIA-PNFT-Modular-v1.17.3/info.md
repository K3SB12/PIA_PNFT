# Estado operativo — PIA-PNFT Modular 1.17.3

2 de octubre de 2026, Costa Rica.

Correcciones solicitadas: botones de Gestionar planeamiento activo con altura automática y texto ajustado; RdA de Ciencia de datos e Inteligencia artificial de II Ciclo con la redacción literal aportada desde la guía de quinto; indicador de Sistema operativo de sexto/Módulo 1 con el texto autorizado. Quinto conserva su indicador de Sistema operativo. El RdA compartido por II Ciclo se actualiza para cuarto, quinto y sexto.

No se migran planeamientos ni se sobrescriben contextualizaciones, prompts o registros guardados. Se conservan versiones, JSON, Proyecto, recursos, seguimiento y exportaciones. npm test aprobó 329 pruebas; evidencia: evidence/npm-test-1.17.3.log.

La referencia histórica y BASELINE.sha256 permanecen intactas. Las pruebas limitan los cambios de los dos catálogos a los dos textos autorizados. La validación visual en dispositivos reales y las descargas/impresión nativas continúan pendientes.

SHA-256 de HTML raíz/web/portable: `d461c8bfaec28bfae9b7d90c61c60b00a3a4aa607c5ed6f5e120c23680a9dc8a`.

Informe: docs/INFORME_VALIDACION_V1.17.3.md.
