import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {createHash} from 'node:crypto';
const digest=text=>createHash('sha256').update(text).digest('hex');

const root=new URL('../',import.meta.url);
const read=name=>readFile(new URL(name,root),'utf8');
const [pnft,rda,operations,reference]=await Promise.all(['src/data/pnft-data.js','src/data/rda-por-ciclo.js','src/domain/curriculum/curriculum-operations.js','reference/index.original.html'].map(read));
const oldRda='Reconoce el uso de la inteligencia artificial en contextos cotidianos y aplica técnicas básicas de recolección, análisis y representación de datos mediante tablas y gráficos.';
const correctedRda='Reconoce cómo se usa la inteligencia artificial; cómo mediante técnicas básicas se recolectan, analizan y representan los datos en tablas y gráficos sencillos.';
const oldIndicator='Identificar la funcionalidad del escritorio en un sistema operativo, reconociendo los elementos básicos de la barra de tareas como altavoces, auriculares, estado de la batería y control de audio, durante el uso cotidiano.';
const correctedIndicator='Identificar herramientas del sistema operativo como el administrador de tareas, la limpieza de archivos temporales y la gestión de memoria, comprendiendo su uso en la optimización del rendimiento del equipo informático.';
const area='Apropiación tecnológica y Digital';
const science='Ciencia de datos e Inteligencia artificial';
const sandbox={document:{getElementById:id=>({value:id==='nivel'?'5°':'II Ciclo'})}};
vm.createContext(sandbox);
vm.runInContext(pnft+'\n'+rda+'\n'+operations+'\nthis.curriculum=PNFT_DATA;',sandbox);

test('solo dos literales curriculares autorizados difieren de la entrega 1.17.2',()=>{
  assert.equal(pnft.split(correctedIndicator).length-1,1);
  assert.equal(rda.split(correctedRda).length-1,1);
  assert.equal(digest(pnft.replace(correctedIndicator,oldIndicator)),'abb6d9b36f0bae67cc0da3e25f61d4fc6dc3b113aed29fa614b13aedfc9f5108');
  assert.equal(digest(rda.replace(correctedRda,oldRda)),'652f1df1de6e5686dc6b1df7b19f46c23615b21eca8da6fd3336a2fc14d40a87');
});

test('quinto obtiene el RdA corregido y conserva su indicador de Sistema operativo',()=>{
  assert.equal(sandbox.obtenerRdaCurricular('II Ciclo',science),correctedRda);
  const saber=sandbox.curriculum['5°']['Módulo 1'][area].saberes.find(s=>s.nombre==='Sistema operativo');
  assert.deepEqual(Array.from(saber.indicadores),[oldIndicator]);
});

test('sexto ofrece exactamente el indicador corregido en Sistema operativo',()=>{
  const saber=sandbox.curriculum['6°']['Módulo 1'][area].saberes.find(s=>s.nombre==='Sistema operativo');
  assert.deepEqual(Array.from(saber.indicadores),[correctedIndicator]);
});
